import requests

def download_file(url, output_path):
    """
    Mengunduh file dari URL yang diberikan dan menyimpannya ke path tertentu.

    Args:
        url (str): URL file yang akan diunduh.
        output_path (str): Path lengkap untuk menyimpan file, termasuk nama file.
    """
    try:
        print(f"Mengunduh dari: {url}")
        
        # Mengirim permintaan HTTP GET
        response = requests.get(url, stream=True)
        response.raise_for_status()  # Memeriksa jika ada error HTTP

        # Menulis konten ke file
        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        print(f"Berhasil mengunduh dan menyimpan ke: {output_path}")

    except requests.exceptions.RequestException as e:
        print(f"Terjadi kesalahan saat mengunduh: {e}")
    except Exception as e:
        print(f"Terjadi kesalahan umum: {e}")

if __name__ == "__main__":
    # URL langsung ke file .zip di GitHub
    # Perhatikan bahwa ini adalah URL langsung ke file, bukan halaman web-nya
    file_url = "https://raw.githubusercontent.com/SoraaAI/Learnity/master/Learnity.zip"
    
    # Path tempat file akan disimpan
    output_filename = "Learnity.zip"
    
    download_file(file_url, output_filename)