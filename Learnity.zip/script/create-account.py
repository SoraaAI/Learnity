import streamlit as st
import json
import os
import random

# Set page config paling atas
st.set_page_config(
    page_title="Buat Akun Baru",
    page_icon="🆕",
    layout="centered",
    initial_sidebar_state="auto",
)

DATA_PATH = "database/user_data.json"

# CSS custom untuk tombol Streamlit
st.markdown(
    """
    <style>
    div.stButton > button {
        width: 100%;
        padding: 10px;
        background-color: #0d6efd;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    div.stButton > button:hover {
        background-color: #0b5ed7;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


def load_user_data():
    if not os.path.exists(DATA_PATH):
        with open(DATA_PATH, "w") as f:
            json.dump([], f)
        return []

    try:
        with open(DATA_PATH, "r") as f:
            data = json.load(f)
            if not isinstance(data, list):
                raise ValueError("Data JSON harus berupa list")
            return data
    except (json.JSONDecodeError, ValueError) as e:
        st.error(f"Error membaca file data pengguna: {e}")
        return []


def save_user_data(data):
    try:
        with open(DATA_PATH, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        st.error(f"Gagal menyimpan data: {e}")


def is_valid_mbti(mbti):
    mbti = mbti.upper()
    valid_letters = [
        ("I", "E"),
        ("N", "S"),
        ("F", "T"),
        ("J", "P"),
    ]
    if len(mbti) != 4:
        return False
    for i, pair in enumerate(valid_letters):
        if mbti[i] not in pair:
            return False
    return True


def generate_unique_userid(existing_ids, length=9):
    while True:
        userid = "".join(str(random.randint(0, 9)) for _ in range(length))
        if userid not in existing_ids:
            return userid


def main():
    st.title("🆕 Buat Akun Baru")
    st.write(
        """
        Isi form di bawah untuk mendaftarkan akun baru.
        User ID akan dibuat otomatis berupa angka unik.
        Nilai tertinggi dan koin akan selalu 0 di belakang layar.
        """
    )

    users = load_user_data()
    existing_userids = {user["userid"] for user in users}

    username = st.text_input("Username", max_chars=30)
    password = st.text_input("Password", type="password", help="Minimal 6 karakter")
    confirm_password = st.text_input("Konfirmasi Password", type="password")
    user_role = st.selectbox(
        "Role User", options=["siswa", "guru"], index=0, help="Pilih peran user"
    )
    mbti = st.text_input(
        "MBTI (misal: INFP)", max_chars=4, help="Format MBTI harus 4 huruf, contoh: ISFJ"
    )
    if st.button("Atau, tebak MBTI kamu dengan mengisi beberapa pertanyaan disini, yuk!", use_container_width=True):
        os.system("python script/question.py")

    submit_button = st.button("Daftar")

    if submit_button:
        errors = []

        if not username.strip():
            errors.append("Username tidak boleh kosong.")
        if len(password) < 6:
            errors.append("Password minimal 6 karakter.")
        if password != confirm_password:
            errors.append("Password dan konfirmasi password tidak sama.")
        if not is_valid_mbti(mbti):
            errors.append(
                "MBTI tidak valid. Pastikan format 4 huruf dengan kombinasi yang benar, misal: INFP, ISFJ."
            )

        for user in users:
            if user["username"].lower() == username.lower():
                errors.append("Username sudah digunakan, coba yang lain.")

        if errors:
            st.error("Terjadi kesalahan:")
            for e in errors:
                st.markdown(f"- {e}")
            return

        userid = generate_unique_userid(existing_userids, length=9)

        new_user = {
            "username": username.strip(),
            "userid": userid,
            "password": password,
            "user_role": user_role,
            "mbti": mbti.upper(),
            "mbti_display": mbti.upper(),
            "owned_char": mbti.upper(),
            "highest_score": 0,
            "coins": 0,
        }

        users.append(new_user)
        try:
            save_user_data(users)
            st.success(f"Akun '{username}' berhasil dibuat dengan User ID: {userid}")
        except Exception as e:
            st.error(f"Gagal menyimpan data pengguna: {e}")


if __name__ == "__main__":
    main()
