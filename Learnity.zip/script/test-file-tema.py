import streamlit as st
from streamlit_plugins.components.theme_changer import st_theme_changer
from utils import get_themes_from_json

# Muat data tema dari file JSON
theme_data = get_themes_from_json()

# Tambahkan st_theme_changer di sidebar untuk mengganti tema
with st.sidebar:
    st_theme_changer(
        themes_data=theme_data,
        render_mode="pills",
        rerun_whole_st=True,
        key="page1_theme_changer"
    )

st.title("Halaman Kustom dengan Tema Bersama")
st.write("Konten di halaman ini akan mengikuti konfigurasi tema yang Anda atur dari halaman utama (app.py).")

st.header("Contoh Elemen Streamlit")
st.text_input("Ini adalah input teks")
st.selectbox("Pilih Opsi", ["Opsi A", "Opsi B", "Opsi C"])
st.button("Tombol")

st.markdown("---")
st.markdown("Teks markdown ini akan berubah warnanya secara otomatis sesuai tema yang dipilih.")