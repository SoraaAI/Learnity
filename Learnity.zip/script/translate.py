import streamlit as st
import speech_recognition as sr
from googletrans import Translator
from gtts import gTTS
import io
import tempfile
import os
from datetime import datetime

st.set_page_config(
    page_title="Penerjemah Audio",
    page_icon="🎙️",
    layout="wide"
)

st.title("🎙️ Penerjemah Audio")
st.markdown("Unggah audio, dapatkan konversi teks instan, lalu terjemahkan ke bahasa apa pun!")

# Inisialisasi status sesi
if 'original_text' not in st.session_state:
    st.session_state.original_text = ""
if 'translated_text' not in st.session_state:
    st.session_state.translated_text = ""
if 'processing_complete' not in st.session_state:
    st.session_state.processing_complete = False

# Pilihan bahasa
LANGUAGES = {
    'Afrikaans': 'af', 'Albanian': 'sq', 'Amharic': 'am', 'Arabic': 'ar',
    'Armenian': 'hy', 'Azerbaijani': 'az', 'Basque': 'eu', 'Belarusian': 'be',
    'Bengali': 'bn', 'Bosnian': 'bs', 'Bulgarian': 'bg', 'Catalan': 'ca',
    'Cebuano': 'ceb', 'Chinese (Simplified)': 'zh-cn', 'Chinese (Traditional)': 'zh-tw',
    'Corsican': 'co', 'Croatian': 'hr', 'Czech': 'cs', 'Danish': 'da',
    'Dutch': 'nl', 'English': 'en', 'Esperanto': 'eo', 'Estonian': 'et',
    'Finnish': 'fi', 'French': 'fr', 'Frisian': 'fy', 'Galician': 'gl',
    'Georgian': 'ka', 'German': 'de', 'Greek': 'el', 'Gujarati': 'gu',
    'Haitian Creole': 'ht', 'Hausa': 'ha', 'Hawaiian': 'haw', 'Hebrew': 'he',
    'Hindi': 'hi', 'Hmong': 'hmn', 'Hungarian': 'hu', 'Icelandic': 'is',
    'Igbo': 'ig', 'Indonesian': 'id', 'Irish': 'ga', 'Italian': 'it',
    'Japanese': 'ja', 'Javanese': 'jw', 'Kannada': 'kn', 'Kazakh': 'kk',
    'Khmer': 'km', 'Korean': 'ko', 'Kurdish': 'ku', 'Kyrgyz': 'ky',
    'Lao': 'lo', 'Latin': 'la', 'Latvian': 'lv', 'Lithuanian': 'lt',
    'Luxembourgish': 'lb', 'Macedonian': 'mk', 'Malagasy': 'mg', 'Malay': 'ms',
    'Malayalam': 'ml', 'Maltese': 'mt', 'Maori': 'mi', 'Marathi': 'mr',
    'Mongolian': 'mn', 'Myanmar': 'my', 'Nepali': 'ne', 'Norwegian': 'no',
    'Odia': 'or', 'Pashto': 'ps', 'Persian': 'fa', 'Polish': 'pl',
    'Portuguese': 'pt', 'Punjabi': 'pa', 'Romanian': 'ro', 'Russian': 'ru',
    'Samoan': 'sm', 'Scots Gaelic': 'gd', 'Serbian': 'sr', 'Sesotho': 'st',
    'Shona': 'sn', 'Sindhi': 'sd', 'Sinhala': 'si', 'Slovak': 'sk',
    'Slovenian': 'sl', 'Somali': 'so', 'Spanish': 'es', 'Sundanese': 'su',
    'Swahili': 'sw', 'Swedish': 'sv', 'Tajik': 'tg', 'Tamil': 'ta',
    'Telugu': 'te', 'Thai': 'th', 'Turkish': 'tr', 'Ukrainian': 'uk',
    'Urdu': 'ur', 'Uyghur': 'ug', 'Uzbek': 'uz', 'Vietnamese': 'vi',
    'Welsh': 'cy', 'Xhosa': 'xh', 'Yiddish': 'yi', 'Yoruba': 'yo', 'Zulu': 'zu'
}

# Pengaturan Sidebar
st.sidebar.header("🔧 Pengaturan Terjemahan")

col1, col2 = st.sidebar.columns(2)
with col1:
    source_lang = st.selectbox(
        "🎤 Dari Bahasa:",
        options=list(LANGUAGES.keys()),
        index=list(LANGUAGES.keys()).index('Indonesian'),
        help="Bahasa dalam file audio"
    )

with col2:
    target_lang = st.selectbox(
        "🗣️ Ke Bahasa:",
        options=list(LANGUAGES.keys()),
        index=list(LANGUAGES.keys()).index('English'),
        help="Bahasa yang akan diterjemahkan"
    )

source_code = LANGUAGES[source_lang]
target_code = LANGUAGES[target_lang]

st.sidebar.subheader("🎵 Pengaturan Audio")
tts_slow = st.sidebar.checkbox("Putar TTS dengan Lambat", value=False)

# Antarmuka Utama
col1, col2 = st.columns([1, 1])

with col1:
    st.header("🎙️ Input Audio")
    
    # Opsi 1: Rekam audio menggunakan browser
    st.subheader("Opsi 1: Rekam Audio")
    st.markdown("**Catatan:** Gunakan fitur perekaman bawaan browser Anda")
    
    # Tambahkan HTML/JS untuk perekaman berbasis browser
    st.markdown("""
    <div style="padding: 20px; border: 2px dashed #ccc; border-radius: 10px; text-align: center;">
        <p>🎤 <strong>Instruksi Perekaman Browser:</strong></p>
        <p>1. Gunakan perekam suara atau fitur dikte di browser Anda</p>
        <p>2. Rekam pesan Anda</p>
        <p>3. Simpan sebagai file audio</p>
        <p>4. Unggah file di bawah ini</p>
    </div>
    """, unsafe_allow_html=True)
    
    st.subheader("Opsi 2: Unggah File Audio")
    uploaded_file = st.file_uploader("📁 Unggah file audio (format .wav)", type=["wav"])
    
    if uploaded_file is not None:
        st.audio(uploaded_file, format='audio/wav')
        
        if st.button("🔄 Konversi Ucapan ke Teks", type="primary"):
            with st.spinner("🎤 Mengonversi ucapan ke teks..."):
                try:
                    # Simpan file yang diunggah sementara
                    with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp_file:
                        tmp_file.write(uploaded_file.getvalue())
                        temp_audio_path = tmp_file.name
                    
                    # Inisialisasi pengenal ucapan
                    recognizer = sr.Recognizer()
                    recognizer.energy_threshold = 300
                    recognizer.pause_threshold = 0.8
                    recognizer.dynamic_energy_threshold = True
                    
                    # Proses file audio
                    with sr.AudioFile(temp_audio_path) as source:
                        st.info(f"Memproses file audio...")
                        recognizer.adjust_for_ambient_noise(source, duration=0.5)
                        audio = recognizer.record(source)
                    
                    # Pemetaan bahasa untuk pengenalan yang lebih baik
                    language_map = {
                        'zh-cn': 'zh-CN',
                        'zh-tw': 'zh-TW', 
                        'id': 'id-ID',
                        'en': 'en-US',
                        'es': 'es-ES',
                        'fr': 'fr-FR',
                        'de': 'de-DE',
                        'it': 'it-IT',
                        'pt': 'pt-BR',
                        'ja': 'ja-JP',
                        'ko': 'ko-KR',
                        'ar': 'ar-SA',
                        'hi': 'hi-IN',
                        'th': 'th-TH',
                        'vi': 'vi-VN',
                        'ms': 'ms-MY'
                    }
                    
                    speech_lang = language_map.get(source_code, source_code)
                    
                    # Coba pengenalan dengan bahasa yang ditentukan
                    try:
                        original_text = recognizer.recognize_google(audio, language=speech_lang)
                        st.session_state.original_text = original_text
                        st.success(f"✅ Teks berhasil diekstrak!")
                        
                    except sr.UnknownValueError:
                        st.warning("⚠️ Tidak dapat memahami dengan bahasa yang ditentukan. Mencoba deteksi otomatis...")
                        try:
                            # Coba tanpa spesifikasi bahasa
                            original_text = recognizer.recognize_google(audio)
                            st.session_state.original_text = original_text
                            st.success(f"✅ Teks berhasil diekstrak dengan deteksi otomatis!")
                            
                        except sr.UnknownValueError:
                            st.error("❌ Tidak dapat memahami audio. Silakan coba:")
                            st.error("• Berbicara lebih jelas")
                            st.error("• Mengurangi kebisingan latar belakang")  
                            st.error("• Menggunakan file audio yang berbeda")
                            st.session_state.original_text = ""
                            
                    except sr.RequestError as e:
                        st.error(f"❌ Kesalahan layanan pengenalan ucapan: {e}")
                        st.session_state.original_text = ""
                        
                    # Bersihkan file sementara
                    if os.path.exists(temp_audio_path):
                        os.unlink(temp_audio_path)
                        
                except Exception as e:
                    st.error(f"❌ Kesalahan saat memproses audio: {e}")
                    st.session_state.original_text = ""

with col2:
    st.header("📝 Teks & Terjemahan")
    
    # Tampilkan teks asli
    st.subheader(f"🎤 Teks yang Diekstrak ({source_lang})")
    if st.session_state.original_text:
        # Izinkan pengeditan teks yang diekstrak
        edited_text = st.text_area(
            "Edit teks jika diperlukan:",
            value=st.session_state.original_text,
            height=100,
            key="original_text_editor"
        )
        st.session_state.original_text = edited_text
        
        st.markdown(f"**Teks saat ini:** {st.session_state.original_text}")
        
        # Tombol terjemahan
        if st.button("🔄 Terjemahkan Teks", type="primary"):
            with st.spinner("🔄 Menerjemahkan..."):
                try:
                    translator = Translator()
                    translation = translator.translate(
                        st.session_state.original_text, 
                        src=source_code, 
                        dest=target_code
                    )
                    st.session_state.translated_text = translation.text
                    st.success(f"✅ Terjemahan selesai!")
                    
                except Exception as e:
                    st.error(f"❌ Kesalahan terjemahan: {e}")
                    st.session_state.translated_text = ""
    else:
        st.info("👆 Unggah file audio dan ubah ke teks terlebih dahulu")
    
    # Tampilkan terjemahan
    if st.session_state.translated_text:
        st.subheader(f"🔄 Terjemahan ({target_lang})")
        st.markdown(f"**{st.session_state.translated_text}**")
        
        # Buat TTS
        if st.button("🗣️ Buat Ucapan", type="secondary"):
            with st.spinner("🗣️ Membuat ucapan..."):
                try:
                    tts_lang = target_code
                    if target_code in ['zh-cn', 'zh-tw']:
                        tts_lang = 'zh'
                    
                    tts = gTTS(
                        text=st.session_state.translated_text, 
                        lang=tts_lang, 
                        slow=tts_slow
                    )
                    
                    audio_buffer = io.BytesIO()
                    tts.write_to_fp(audio_buffer)
                    audio_buffer.seek(0)
                    
                    st.success("🗣️ Audio terjemahan siap!")
                    st.audio(audio_buffer.getvalue(), format="audio/mp3")
                    
                    st.download_button(
                        label="📥 Unduh Audio Terjemahan",
                        data=audio_buffer.getvalue(),
                        file_name=f"translation_{target_lang.lower().replace(' ', '_')}.mp3",
                        mime="audio/mp3"
                    )
                except Exception as e:
                    st.error(f"❌ Kesalahan teks-ke-ucapan: {e}")

# Bagian Hasil
st.markdown("---")
st.header("📋 Ringkasan Hasil")

if st.session_state.original_text or st.session_state.translated_text:
    result_col1, result_col2 = st.columns(2)
    
    with result_col1:
        st.subheader(f"🎤 Asli ({source_lang})")
        if st.session_state.original_text:
            st.markdown(f"*{st.session_state.original_text}*")
        else:
            st.markdown("*Tidak ada teks tersedia*")
    
    with result_col2:
        st.subheader(f"🔄 Terjemahan ({target_lang})")
        if st.session_state.translated_text:
            st.markdown(f"*{st.session_state.translated_text}*")
        else:
            st.markdown("*Tidak ada terjemahan tersedia*")
    
    if st.button("🗑️ Hapus Semua Hasil"):
        st.session_state.original_text = ""
        st.session_state.translated_text = ""
        st.session_state.processing_complete = False
        st.rerun()

else:
    st.info("🎯 Unggah file audio untuk memulai!")

# Instruksi
st.markdown("---")
st.markdown("### 📋 Cara Penggunaan")

with st.expander("Klik di sini untuk instruksi detail"):
    st.markdown("""
    ## Panduan Langkah-demi-Langkah
    
    **Langkah 1: Pengaturan**
    - Pilih bahasa sumber (bahasa yang diucapkan dalam audio)
    - Pilih bahasa target (bahasa yang akan diterjemahkan)
    
    **Langkah 2: Dapatkan Audio**
    - **Opsi A:** Rekam menggunakan perekam suara browser/perangkat Anda, lalu unggah
    - **Opsi B:** Unggah file audio yang sudah ada (WAV, MP3, MP4, M4A, FLAC, AAC, OGG)
    
    **Langkah 3: Konversi Ucapan ke Teks**
    - Klik "Konversi Ucapan ke Teks"
    - Aplikasi akan secara otomatis mengekstrak teks dari audio Anda
    - Anda dapat mengedit teks yang diekstrak jika diperlukan
    
    **Langkah 4: Terjemahkan**
    - Klik "Terjemahkan Teks" untuk mendapatkan terjemahan
    - Tinjau teks yang sudah diterjemahkan
    
    **Langkah 5: Buat Ucapan (Opsional)**
    - Klik "Buat Ucapan" untuk mendengarkan terjemahan
    - Unduh file audio jika diperlukan
    
    ## 💡 Tips untuk Hasil Terbaik
    - **Audio jelas**: Bicaralah dengan jelas dan minimalkan kebisingan latar belakang
    - **Kualitas baik**: File audio berkualitas tinggi bekerja lebih baik
    - **Bahasa yang benar**: Pastikan bahasa sumber cocok dengan audio Anda
    - **Klip pendek**: Klip audio yang lebih pendek (di bawah 1 menit) memberikan hasil terbaik
    - **Internet stabil**: Diperlukan untuk pengenalan ucapan dan terjemahan
    
    ## 🎤 Tips Merekam
    - Gunakan aplikasi perekam suara di ponsel Anda
    - Rekam di lingkungan yang tenang
    - Bicaralah dengan kecepatan normal, secara jelas
    - Pertahankan rekaman di bawah 30 detik untuk hasil terbaik
    """)

st.markdown("### ✨ Fitur")
feature_cols = st.columns(3)

with feature_cols[0]:
    st.markdown("""
    **🎤 Ucapan-ke-Teks**
    - Mendukung berbagai format audio
    - Dukungan multi-bahasa
    - Teks hasil yang dapat diedit
    """)

with feature_cols[1]:
    st.markdown("""
    **🔄 Terjemahan**
    - 100+ pasangan bahasa
    - Terjemahan instan
    - Didukung oleh Google Translate
    """)

with feature_cols[2]:
    st.markdown("""
    **🗣️ Teks-ke-Ucapan**
    - Sintesis suara alami
    - Kecepatan yang dapat disesuaikan
    - Audio dapat diunduh
    """)
