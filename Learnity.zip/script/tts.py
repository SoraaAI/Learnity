import streamlit as st
import os
import tempfile
import base64
from io import BytesIO

try:
    from gtts import gTTS
    GTTS_AVAILABLE = True
except ImportError:
    GTTS_AVAILABLE = False

st.set_page_config(
    page_title="Text-to-Speech Converter",
    page_icon="🎤",
    layout="wide"
)

st.title("🎤 Text-to-Speech Converter")
st.markdown("Convert your text to natural-sounding speech.")

st.sidebar.header("🔧 Configuration")

if not GTTS_AVAILABLE:
    st.sidebar.error("❌ gTTS library not found!")
    st.sidebar.markdown("Install gTTS:")
    st.sidebar.code("pip install gtts")
    st.error("Please install gTTS first: `pip install gtts`")
    st.stop()

st.sidebar.markdown("### Text-to-Speech")
st.sidebar.info("""
- Requires internet connection
- Supports 100+ languages
- Easy to use with no API keys required
""")
st.sidebar.success("✅ Siap digunakan.")

col1, col2 = st.columns([2, 1])

with col1:
    st.header("📝 Text Input")
    text_input = st.text_area(
        "Enter the text you want to convert to speech:",
        height=200,
        placeholder="Type or paste your text here...",
        help="Maximum 5000 characters"
    )
    
    char_count = len(text_input)
    if char_count > 5000:
        st.error(f"Text too long! Current: {char_count} characters. Maximum: 5000 characters.")
    else:
        st.info(f"Character count: {char_count}/5000")

with col2:
    st.header("🎛️ Voice Settings")
    
    gtts_languages = {
        'English': 'en',
        'Indonesian': 'id',
        'Spanish': 'es',
        'French': 'fr',
        'German': 'de',
        'Italian': 'it',
        'Portuguese': 'pt',
        'Russian': 'ru',
        'Japanese': 'ja',
        'Korean': 'ko',
        'Chinese': 'zh',
        'Arabic': 'ar',
        'Hindi': 'hi',
        'Dutch': 'nl',
        'Swedish': 'sv',
        'Norwegian': 'no',
        'Danish': 'da',
        'Finnish': 'fi',
        'Polish': 'pl',
        'Czech': 'cs',
        'Hungarian': 'hu',
        'Romanian': 'ro',
        'Bulgarian': 'bg',
        'Croatian': 'hr',
        'Slovak': 'sk',
        'Slovenian': 'sl',
        'Estonian': 'et',
        'Latvian': 'lv',
        'Lithuanian': 'lt',
        'Ukrainian': 'uk',
        'Greek': 'el',
        'Turkish': 'tr',
        'Hebrew': 'he',
        'Thai': 'th',
        'Vietnamese': 'vi',
        'Malay': 'ms'
    }
    
    selected_language = st.selectbox(
        "Select Language:",
        options=list(gtts_languages.keys()),
        index=1,
        help="Choose the language for speech synthesis"
    )
    language_code = gtts_languages[selected_language]
    
    st.subheader("🎵 Audio Settings")
    slow_speech = st.checkbox(
        "Slow Speech", 
        value=False,
        help="Enable for slower speech rate"
    )
    
    st.subheader("📊 Advanced Settings")
    
    tld_options = {
        'Default (com)': 'com',
        'Australia (com.au)': 'com.au',
        'United Kingdom (co.uk)': 'co.uk',
        'Canada (ca)': 'ca',
        'India (co.in)': 'co.in',
        'Ireland (ie)': 'ie',
        'South Africa (co.za)': 'co.za'
    }
    
    selected_tld = st.selectbox(
        "Voice Accent (TLD):",
        options=list(tld_options.keys()),
        index=0,
        help="Different accents based on Google's regional domains"
    )
    tld = tld_options[selected_tld]
    
    st.info("💡 Tip: Different TLD options may provide slightly different voice accents for the same language")

def generate_speech_gtts(text, language_code, slow=False, tld='com'):
    try:
        tts = gTTS(text=text, lang=language_code, slow=slow, tld=tld)
        audio_buffer = BytesIO()
        tts.write_to_fp(audio_buffer)
        audio_buffer.seek(0)
        return audio_buffer.getvalue()
    except Exception as e:
        st.error(f"Error generating speech: {str(e)}")
        return None

st.header("🎧 Generated Audio")

if st.button("🎤 Convert Text to Speech", type="primary", use_container_width=True):
    if not text_input.strip():
        st.warning("Please enter some text to convert.")
    elif len(text_input) > 5000:
        st.error("Text is too long. Please reduce to 5000 characters or less.")
    else:
        with st.spinner("Generating speech... Please wait."):
            audio_content = generate_speech_gtts(
                text_input,
                language_code,
                slow_speech,
                tld
            )
            
            if audio_content:
                st.success("✅ Speech generated successfully!")
                st.audio(audio_content, format="audio/mp3")
                st.download_button(
                    label="📥 Download Audio File",
                    data=audio_content,
                    file_name=f"speech_{selected_language.lower()}.mp3",
                    mime="audio/mp3"
                )
                st.info(f"🌍 Language: {selected_language} | 🐌 Slow: {'Yes' if slow_speech else 'No'} | 🌐 Accent: {selected_tld}")

st.markdown("---")
st.markdown("### 📋 Setup Instructions")

with st.expander("Click here for setup instructions"):
    st.markdown("""
    ## Quick Setup (gTTS)
    **Easy setup - Just install and run!**
    
    **Install Dependencies:**
    ```bash
    pip install streamlit gtts
    ```
    
    **Run the application:**
    ```bash
    streamlit run your_script_name.py
    ```
    
    **Features:**
    - ✅ Free to use
    - ✅ No API keys required
    - ✅ 100+ languages supported
    - ✅ Multiple accent options
    - ✅ Speed control
    - ❌ Requires internet connection
    - ❌ Limited voice customization compared to premium services
    
    **Supported Languages:**
    The app supports a wide range of languages including English, Indonesian, Spanish, French, German, Italian, Portuguese, Russian, Japanese, Korean, Chinese, Arabic, Hindi, and many more!
    
    **Voice Accents:**
    Different TLD (Top-Level Domain) options provide slightly different accents:
    - `com`: Default Google voice
    - `com.au`: Australian accent
    - `co.uk`: British accent  
    - `ca`: Canadian accent
    - `co.in`: Indian accent
    - And more...
    """)

st.markdown("### ℹ️ gTTS Features")
st.markdown("""
- **100+ Languages**: Extensive language support including Indonesian
- **Multiple Accents**: Different regional accents via TLD selection
- **Speed Control**: Normal or slow speech options
- **Free Service**: No API keys or paid subscriptions required
- **High Quality**: Good quality audio output
- **Easy to Use**: Simple interface with immediate results
- **Download Option**: Save generated audio as MP3 files
""")

st.markdown("### 🌍 Popular Languages Available")
popular_langs = ['English', 'Indonesian', 'Spanish', 'French', 'German', 'Japanese', 'Chinese', 'Arabic', 'Hindi', 'Portuguese']
cols = st.columns(5)
for i, lang in enumerate(popular_langs):
    with cols[i % 5]:
        st.markdown(f"🔸 {lang}")

st.markdown("### 💡 Tips for Best Results")
st.markdown("""
- **Punctuation matters**: Use proper punctuation for natural pauses
- **Numbers**: Write numbers as words for better pronunciation
- **Abbreviations**: Spell out abbreviations (e.g., "Doctor" instead of "Dr.")
- **Language consistency**: Keep text in the selected language for best results
- **Internet required**: gTTS requires an active internet connection
""")
