import sys
import streamlit as st
import json

from streamlit_plugins.components.theme_changer import get_active_theme_key, st_theme_changer
from streamlit_plugins.components.theme_changer.entity import ThemeInput, ThemeInfo, ThemeBaseLight, ThemeBaseDark
from utils import get_themes_from_json, save_themes_to_json

# make it look nice from the start
st.title("Theme Changer Component")
st.caption("Just push the button to change the theme! On the client side, of course.")

st.markdown(
    """
    <style>
    div.stButton > button {
        width: 100%;
        padding: 10px;
        background-color: #0d6efd;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    div.stButton > button:hover {
        background-color: #0b5ed7;
        color: white;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <style>
    div.stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
    }
    </style>
    """,
    unsafe_allow_html=True
)

if "theme_data" not in st.session_state:
    st.session_state["theme_data"] = get_themes_from_json()

theme_data = st.session_state["theme_data"]

st_theme_changer(themes_data=theme_data, render_mode="init", default_init_theme_name="soft_light")
st_theme_changer(themes_data=theme_data, rerun_whole_st=True)

with st.expander("Theme Editor", expanded=False):
    with st.container(border=False):
        
        # --- Add New Theme Section ---
        st.subheader("Add New Theme")
        with st.form(key="add_theme_form"):
            new_theme_key = st.text_input("New Theme Key (e.g., 'my_custom_theme')", value="new_theme_key")
            new_theme_name = st.text_input("New Theme Name", value="My Custom Theme")
            new_theme_icon = st.text_input("New Theme Icon", value=":material/palette:", help="Format: :material/nama_ikon: (Bisa kamu cari kode nama ikon nya di: https://fonts.google.com/icons)")
            new_theme_base_str = st.selectbox("Base Theme", ["light", "dark"])
            
            add_theme_button = st.form_submit_button("Add Theme")
            
            if add_theme_button:
                if new_theme_key in theme_data:
                    st.warning(f"Theme key '{new_theme_key}' already exists. Please choose a different key.")
                else:
                    new_theme_base = ThemeBaseLight.base if new_theme_base_str == "light" else ThemeBaseDark.base
                    
                    new_theme_info = ThemeInfo(
                        base=new_theme_base,
                        primaryColor="#007bff" if new_theme_base_str == "light" else "#7af8ff",
                        backgroundColor="#ffffff" if new_theme_base_str == "light" else "#000000",
                        secondaryBackgroundColor="#f0f2f6" if new_theme_base_str == "light" else "#045367",
                        textColor="#000000" if new_theme_base_str == "light" else "#f0f8ff",
                        bodyFont="sans serif",
                        codeFont="monospace",
                        fontFaces=[],
                        radii={"baseWidgetRadius": 0, "checkboxRadius": 0},
                        fontSizes={"tinyFontSize": 10, "smallFontSize": 12, "baseFontSize": 14}
                    )
                    theme_data[new_theme_key] = ThemeInput(
                        name=new_theme_name,
                        icon=new_theme_icon,
                        order=len(theme_data),
                        themeInfo=new_theme_info
                    )
                    st.session_state["theme_data"] = theme_data
                    save_themes_to_json(theme_data)
                    st.success(f"Theme '{new_theme_name}' added successfully!")
                    st.rerun()

        st.subheader("Edit Existing Themes")
        theme_keys = list(theme_data.keys())
        tabs = st.tabs(theme_keys)
        for i, tab in enumerate(tabs):
            theme_key = theme_keys[i]
            with tab:
                with st.form(key=f"{theme_key}_form", border=False):
                    col1, col2, col3 = st.columns(3)
                    name = col1.text_input("Theme Label", value=theme_data[theme_key].name, key=f"{theme_key}_text_input")
                    icon = col2.text_input("Theme Icon", value=theme_data[theme_key].icon, key=f"{theme_key}_icon_input")
                    order = col3.number_input("Order", value=theme_data[theme_key].order, key=f"{theme_key}_order_input")
                    
                    col1, col2, col3 = st.columns(3)
                    primaryColor = col1.color_picker("Primary Color", value=theme_data[theme_key].themeInfo.primaryColor, key=f"{theme_key}_primary_color_input")
                    textColor = col2.color_picker("Text Color", value=theme_data[theme_key].themeInfo.textColor, key=f"{theme_key}_text_color_input")
                    
                    col1, col2, col3 = st.columns(3)
                    backgroundColor = col1.color_picker("Background Color", value=theme_data[theme_key].themeInfo.backgroundColor, key=f"{theme_key}_background_color_input")
                    secondaryBackgroundColor = col2.color_picker("Secondary Background Color", value=theme_data[theme_key].themeInfo.secondaryBackgroundColor, key=f"{theme_key}_secondary_background_color_input")
                    skeletonBackgroundColor = col3.color_picker("Skeleton Background Color", value=theme_data[theme_key].themeInfo.skeletonBackgroundColor, key=f"{theme_key}_skeleton_background_color_input")
                    
                    col1, col2, col3 = st.columns(3)
                    widgetBackgroundColor = col1.color_picker("Widget Background Color", value=theme_data[theme_key].themeInfo.widgetBackgroundColor, key=f"{theme_key}_widget_background_color_input")
                    widgetBorderColor = col2.color_picker("Widget Border Color", value=theme_data[theme_key].themeInfo.widgetBorderColor, key=f"{theme_key}_widget_border_color_input")
                    
                    baseWidgetRadius = col3.number_input("Base Widget Radius", value=theme_data[theme_key].themeInfo.radii.get("baseWidgetRadius", 0), key=f"{theme_key}_base_widget_radius_input")

                    col1, col2, col3 = st.columns(3)
                    checkbox_radius = col1.number_input("Checkbox Radius", value=theme_data[theme_key].themeInfo.radii.get("checkboxRadius", 0), key=f"{theme_key}_checkbox_radius_input")
                    col2.checkbox("Example Checkbox", key=f"{theme_key}_example_checkbox")
                    
                    col1, col2, col3 = st.columns(3)
                    tiny_font_size = col1.number_input("Tiny Font Size", value=theme_data[theme_key].themeInfo.fontSizes.get("tinyFontSize", 10), key=f"{theme_key}_tiny_font_size_input")
                    small_font_size = col2.number_input("Small Font Size", value=theme_data[theme_key].themeInfo.fontSizes.get("smallFontSize", 12), key=f"{theme_key}_small_font_size_input")
                    base_font_size = col3.number_input("Base Font Size", value=theme_data[theme_key].themeInfo.fontSizes.get("baseFontSize", 14), key=f"{theme_key}_base_font_size_input")

                    col1, col2 = st.columns(2)
                    bodyFont_input = col1.text_input(
                        "Body Font", 
                        value=theme_data[theme_key].themeInfo.bodyFont, 
                        key=f"{theme_key}_body_font_input",
                        help="e.g. \"Victor Mono Italic\", Source Sans Pro, sans-serif"
                    )
                    codeFont_input = col2.text_input(
                        "Code Font", 
                        value=theme_data[theme_key].themeInfo.codeFont, 
                        key=f"{theme_key}_code_font_input",
                        help="e.g. \"Victor Mono\", Source Code Pro, monospace"
                    )

                    update_theme = st.form_submit_button("Save Changes")
                    if update_theme:
                        # Tentukan nilai default jika input string kosong
                        body_font_value = bodyFont_input if bodyFont_input.strip() else "sans serif"
                        code_font_value = codeFont_input if codeFont_input.strip() else "monospace"
                        
                        theme_data[theme_key].name = name
                        theme_data[theme_key].icon = icon
                        theme_data[theme_key].order = order
                        theme_data[theme_key].themeInfo.primaryColor = primaryColor
                        theme_data[theme_key].themeInfo.backgroundColor = backgroundColor
                        theme_data[theme_key].themeInfo.secondaryBackgroundColor = secondaryBackgroundColor
                        theme_data[theme_key].themeInfo.textColor = textColor
                        theme_data[theme_key].themeInfo.widgetBackgroundColor = widgetBackgroundColor
                        theme_data[theme_key].themeInfo.widgetBorderColor = widgetBorderColor
                        theme_data[theme_key].themeInfo.skeletonBackgroundColor = skeletonBackgroundColor
                        theme_data[theme_key].themeInfo.bodyFont = body_font_value
                        theme_data[theme_key].themeInfo.codeFont = code_font_value
                        theme_data[theme_key].themeInfo.radii["baseWidgetRadius"] = baseWidgetRadius
                        theme_data[theme_key].themeInfo.fontSizes["tinyFontSize"] = tiny_font_size
                        theme_data[theme_key].themeInfo.fontSizes["smallFontSize"] = small_font_size
                        theme_data[theme_key].themeInfo.fontSizes["baseFontSize"] = base_font_size

                        save_themes_to_json(theme_data)
                        
                        if get_active_theme_key() == theme_key:
                            st_theme_changer(themes_data=theme_data, render_mode="change", default_init_theme_name=theme_key)
                            st.rerun()

with st.sidebar:
    st_theme_changer(
        themes_data=theme_data, render_mode="pills",
        rerun_whole_st=True, key="first_pills"
    )