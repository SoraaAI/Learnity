import streamlit as st
import random
import json
import os
import hashlib

# Session state initialization
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'current_user' not in st.session_state:
    st.session_state.current_user = None

# Quiz data management functions
def load_quiz_data():
    """Load quiz data from database/quiz_data.json"""
    try:
        if not os.path.exists('database'):
            os.makedirs('database')
        
        if os.path.exists('database/quiz_data.json'):
            with open('database/quiz_data.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            # Create default quiz data if file doesn't exist
            default_quiz_data = {
                "Matematika": [
                    {
                        "q": "Berapa hasil dari 2 + 2?",
                        "a": "4",
                        "options": ["3", "4", "5", "6"]
                    },
                    {
                        "q": "Berapa hasil dari 5 x 3?",
                        "a": "15",
                        "options": ["12", "15", "18", "20"]
                    }
                ],
                "Sejarah": [
                    {
                        "q": "Siapa proklamator kemerdekaan Indonesia?",
                        "a": "Soekarno dan Hatta",
                        "options": ["Soekarno dan Hatta", "Soekarno dan Sjahrir", "Hatta dan Sjahrir", "Soekarno saja"]
                    }
                ]
            }
            save_quiz_data(default_quiz_data)
            return default_quiz_data
    except Exception as e:
        st.error(f"Error loading quiz data: {e}")
        return {}

def save_quiz_data(data):
    """Save quiz data to database/quiz_data.json"""
    try:
        if not os.path.exists('database'):
            os.makedirs('database')
        
        with open('database/quiz_data.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        st.error(f"Error saving quiz data: {e}")

# User management functions
def load_users():
    """Load users data from database/user_data.json"""
    try:
        if not os.path.exists('database'):
            os.makedirs('database')
        
        if os.path.exists('database/user_data.json'):
            with open('database/user_data.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            # Create default users if file doesn't exist (as array format)
            default_users = [
                {
                    "username": "admin",
                    "userid": "admin123",
                    "password": "admin123",
                    "user_role": "guru",
                    "mbti": "INTJ",
                    "highest_score": 0,
                    "coins": 0
                },
                {
                    "username": "student1",
                    "userid": "student123",
                    "password": "student123",
                    "user_role": "siswa",
                    "mbti": "ISFJ",
                    "highest_score": 0,
                    "coins": 0
                }
            ]
            save_users(default_users)
            return default_users
    except Exception as e:
        st.error(f"Error loading users data: {e}")
        return []

def save_users(users_data):
    """Save users data to database/user_data.json"""
    try:
        if not os.path.exists('database'):
            os.makedirs('database')
        
        with open('database/user_data.json', 'w', encoding='utf-8') as f:
            json.dump(users_data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        st.error(f"Error saving users data: {e}")

def authenticate_user(username_or_id, password):
    """Authenticate user with username/userid and password"""
    users = load_users()
    
    for user_data in users:
        if (user_data.get("username") == username_or_id or 
            user_data.get("userid") == username_or_id) and \
           user_data.get("password") == password:
            return user_data
    return None

def update_user_data(username, coins_change=0, new_score=None):
    """Update user coins and highest score"""
    users = load_users()
    updated = False
    is_new_high = False
    
    for user_data in users:
        if user_data.get("username") == username:
            # Update coins
            user_data['coins'] = max(0, user_data.get('coins', 0) + coins_change)
            
            # Update highest score if provided and higher
            if new_score is not None and new_score > user_data.get('highest_score', 0):
                user_data['highest_score'] = new_score
                is_new_high = True
            
            updated = True
            break
    
    if updated:
        save_users(users)
    
    return is_new_high

def add_coins(username, amount):
    """Add coins to user"""
    update_user_data(username, coins_change=amount)
    users = load_users()
    for user_data in users:
        if user_data.get("username") == username:
            return user_data.get('coins', 0)
    return 0

def update_highest_score(username, current_score):
    """Update highest score if current score is higher"""
    return update_user_data(username, new_score=current_score)

# Crate system
CRATES = [
    {"name": "Heart Boost", "type": "buff", "icon": "💚", "description": "Restore 1 heart"},
    {"name": "Heart Loss", "type": "debuff", "icon": "💔", "description": "Remove 1 heart"},
    {"name": "Coin Boost", "type": "buff", "icon": "🪙", "description": "Add 10 coins"},
    {"name": "Coin Loss", "type": "debuff", "icon": "💸", "description": "Remove 10 coins"},
    {"name": "Score Boost", "type": "buff", "icon": "⭐", "description": "1.5x score for next 3 questions"},
    {"name": "Break", "type": "buff", "icon": "🛡️", "description": "Skip next question without penalty"},
    {"name": "Double Trouble", "type": "neutral", "icon": "⚡", "description": "Next question: 2x points & 2x penalty"},
    {"name": "Disaster!", "type": "debuff", "icon": "💀", "description": "Max questions increased by 5"},
    {"name": "Lucky Charm", "type": "buff", "icon": "🍀", "description": "Next wrong answer doesn't cost a heart"},
    {"name": "Time Warp", "type": "buff", "icon": "🕐", "description": "Reduce max questions by 2"},
    {"name": "Coin Rain", "type": "buff", "icon": "💰", "description": "Double coin rewards for next 3 questions"},
    {"name": "Confusion", "type": "debuff", "icon": "🌀", "description": "Next question has shuffled options"},
]

def get_random_crate():
    """Get a random crate"""
    return random.choice(CRATES)

def apply_crate_effect(crate):
    """Apply the effect of a crate"""
    effect_msg = ""
    
    if crate["name"] == "Heart Boost":
        max_hearts = get_hearts_by_difficulty(st.session_state.selected_difficulty)
        if st.session_state.hearts < max_hearts:
            st.session_state.hearts += 1
            effect_msg = "💚 +1 Heart restored!"
        else:
            effect_msg = "💚 Hearts already at maximum!"
    
    elif crate["name"] == "Heart Loss":
        if st.session_state.hearts > 1:
            st.session_state.hearts -= 1
            effect_msg = "💔 -1 Heart lost!"
        else:
            effect_msg = "💔 Can't lose heart - you only have 1 left!"
    
    elif crate["name"] == "Coin Boost":
        new_total = add_coins(st.session_state.current_user['username'], 10)
        effect_msg = f"🪙 +10 Coins! (Total: {new_total})"
    
    elif crate["name"] == "Coin Loss":
        new_total = add_coins(st.session_state.current_user['username'], -10)
        effect_msg = f"💸 -10 Coins! (Total: {new_total})"
    
    elif crate["name"] == "Score Boost":
        st.session_state.score_boost_remaining = 3
        effect_msg = "⭐ Score boost active for next 3 questions!"
    
    elif crate["name"] == "Break":
        st.session_state.skip_next_question = True
        effect_msg = "🛡️ Next question will be skipped!"
    
    elif crate["name"] == "Double Trouble":
        st.session_state.double_trouble_next = True
        effect_msg = "⚡ Next question: Double risk, double reward!"
    
    elif crate["name"] == "Disaster!":
        st.session_state.question_limit += 5
        effect_msg = f"💀 Oh no! +5 questions added! New limit: {st.session_state.question_limit}"
    
    elif crate["name"] == "Lucky Charm":
        st.session_state.lucky_charm_active = True
        effect_msg = "🍀 Lucky charm active - next wrong answer is free!"
    
    elif crate["name"] == "Time Warp":
        if st.session_state.question_limit > 2:
            st.session_state.question_limit = max(1, st.session_state.question_limit - 2)
            effect_msg = f"🕐 Time warp! -2 questions! New limit: {st.session_state.question_limit}"
        else:
            effect_msg = "🕐 Time warp failed - too few questions remaining!"
    
    elif crate["name"] == "Coin Rain":
        st.session_state.coin_rain_remaining = 3
        effect_msg = "💰 Coin rain active - double coins for next 3 questions!"
    
    elif crate["name"] == "Confusion":
        st.session_state.confusion_next = True
        effect_msg = "🌀 Next question will have shuffled options!"
    
    return effect_msg

# Initialize session state for game
if 'game_started' not in st.session_state:
    st.session_state.game_started = False
if 'hearts' not in st.session_state:
    st.session_state.hearts = 5
if 'score' not in st.session_state:
    st.session_state.score = 0
if 'current_question' not in st.session_state:
    st.session_state.current_question = None
if 'questions_used' not in st.session_state:
    st.session_state.questions_used = []
if 'selected_subject' not in st.session_state:
    st.session_state.selected_subject = None
if 'selected_difficulty' not in st.session_state:
    st.session_state.selected_difficulty = None
if 'game_over' not in st.session_state:
    st.session_state.game_over = False
if 'answer_submitted' not in st.session_state:
    st.session_state.answer_submitted = False
if 'feedback_message' not in st.session_state:
    st.session_state.feedback_message = ""
if 'question_limit' not in st.session_state:
    st.session_state.question_limit = 5
if 'questions_answered' not in st.session_state:
    st.session_state.questions_answered = 0
if 'victory' not in st.session_state:
    st.session_state.victory = False
if 'score_boost_remaining' not in st.session_state:
    st.session_state.score_boost_remaining = 0
if 'skip_next_question' not in st.session_state:
    st.session_state.skip_next_question = False
if 'double_trouble_next' not in st.session_state:
    st.session_state.double_trouble_next = False
if 'lucky_charm_active' not in st.session_state:
    st.session_state.lucky_charm_active = False
if 'coin_rain_remaining' not in st.session_state:
    st.session_state.coin_rain_remaining = 0
if 'confusion_next' not in st.session_state:
    st.session_state.confusion_next = False
if 'crate_message' not in st.session_state:
    st.session_state.crate_message = ""
if 'show_crate' not in st.session_state:
    st.session_state.show_crate = False
if 'show_question_manager' not in st.session_state:
    st.session_state.show_question_manager = False

def reset_game():
    st.session_state.game_started = False
    st.session_state.hearts = 5
    st.session_state.score = 0
    st.session_state.current_question = None
    st.session_state.questions_used = []
    st.session_state.selected_subject = None
    st.session_state.selected_difficulty = None
    st.session_state.game_over = False
    st.session_state.answer_submitted = False
    st.session_state.feedback_message = ""
    st.session_state.questions_answered = 0
    st.session_state.victory = False
    st.session_state.score_boost_remaining = 0
    st.session_state.skip_next_question = False
    st.session_state.double_trouble_next = False
    st.session_state.lucky_charm_active = False
    st.session_state.coin_rain_remaining = 0
    st.session_state.confusion_next = False
    st.session_state.crate_message = ""
    st.session_state.show_crate = False
    st.session_state.show_question_manager = False

def get_hearts_by_difficulty(difficulty):
    if difficulty == "Easy":
        return 5
    elif difficulty == "Medium":
        return 3
    elif difficulty == "Hard":
        return 1

def get_random_question(subject):
    quiz_data = load_quiz_data()
    
    # Check if skip is active
    if st.session_state.skip_next_question:
        st.session_state.skip_next_question = False
        st.session_state.questions_answered += 1
        st.session_state.crate_message = "🛡️ Question skipped! No penalty!"
        
        # Check for victory after skip
        if st.session_state.questions_answered >= st.session_state.question_limit:
            st.session_state.victory = True
        
        return get_random_question(subject)  # Get the actual next question
    
    available_questions = [q for q in quiz_data[subject] if q not in st.session_state.questions_used]
    if not available_questions:
        st.session_state.questions_used = []
        available_questions = quiz_data[subject]
    
    question = random.choice(available_questions)
    st.session_state.questions_used.append(question)
    
    # Apply confusion effect if active
    if st.session_state.confusion_next:
        st.session_state.confusion_next = False
        # Shuffle the options
        question = question.copy()
        question['options'] = question['options'].copy()
        random.shuffle(question['options'])
        st.session_state.crate_message = "🌀 Options have been shuffled!"
    
    return question

def check_answer(selected_answer, correct_answer):
    base_score = 10
    coin_reward = 2
    
    # Apply score boost if active
    if st.session_state.score_boost_remaining > 0:
        base_score = int(base_score * 1.5)
        st.session_state.score_boost_remaining -= 1
    
    # Apply double trouble if active
    if st.session_state.double_trouble_next:
        base_score *= 2
        st.session_state.double_trouble_next = False
    
    # Apply coin rain if active
    if st.session_state.coin_rain_remaining > 0:
        coin_reward *= 2
        st.session_state.coin_rain_remaining -= 1
    
    if selected_answer == correct_answer:
        st.session_state.score += base_score
        
        # Add coins to user data
        new_coin_total = add_coins(st.session_state.current_user['username'], coin_reward)
        
        # Update highest score
        is_new_high = update_highest_score(st.session_state.current_user['username'], st.session_state.score)
        high_score_msg = " 🏆 NEW HIGH SCORE!" if is_new_high else ""
        
        coin_msg = f"+{coin_reward} coins" if coin_reward == 2 else f"+{coin_reward} coins (Rain!)"
        boost_msg = " (Boosted!)" if st.session_state.score_boost_remaining >= 0 and base_score > 10 else ""
        double_msg = " (Double!)" if base_score == 40 else ""  # 20 * 2 or 15 * 2
        
        st.session_state.feedback_message = f"🎉 Benar! +{base_score} poin{boost_msg}{double_msg}, {coin_msg} (Total: {new_coin_total}){high_score_msg}"
        
        # Increment questions answered
        st.session_state.questions_answered += 1
        
        # Check for crate every 5 questions
        if st.session_state.questions_answered % 5 == 0:
            crate = get_random_crate()
            effect_msg = apply_crate_effect(crate)
            st.session_state.crate_message = f"📦 {crate['icon']} {crate['name']}: {effect_msg}"
            st.session_state.show_crate = True
        
        # Check for victory condition
        if st.session_state.questions_answered >= st.session_state.question_limit:
            st.session_state.victory = True
        
        return True
    else:
        # Check lucky charm
        if st.session_state.lucky_charm_active:
            st.session_state.lucky_charm_active = False
            st.session_state.feedback_message = f"🍀 Lucky charm saved you! Correct answer: {correct_answer}"
        else:
            # Apply double trouble penalty if active
            heart_loss = 2 if st.session_state.double_trouble_next else 1
            if st.session_state.double_trouble_next:
                st.session_state.double_trouble_next = False
            
            st.session_state.hearts -= heart_loss
            penalty_msg = f" (-{heart_loss} hearts)" if heart_loss > 1 else ""
            st.session_state.feedback_message = f"❌ Salah{penalty_msg}! Jawaban yang benar: {correct_answer}"
            
            if st.session_state.hearts <= 0:
                st.session_state.game_over = True
        return False

# Main UI
st.set_page_config(page_title="Learnity Quiz Game", page_icon="🎯", layout="wide")
st.markdown(
    """
    <style>
    div.stButton > button {
        width: 100%;
        padding: 10px;
        background-color: #0d6efd;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    div.stButton > button:hover {
        background-color: #0b5ed7;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <style>
    div.stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
    }
    </style>
    """,
    unsafe_allow_html=True
)
# Login Screen
if not st.session_state.logged_in:
    st.markdown("""
        <style>
        .center-text {
            text-align: center;
        }
        </style>
    """, unsafe_allow_html=True)

    # Gunakan div dengan class center-text
    st.markdown('<h1 class="center-text">🎯 Welcome to Learnity Quiz Game</h1>', unsafe_allow_html=True)
    st.markdown('<h3 class="center-text">🔐 Please Login to Continue</h3>', unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.markdown("---")
        
        username_input = st.text_input(
            "Username or User ID",
            placeholder="Enter your username or user ID",
            help="Masukan username atau user ID kamu."
        )
        password_input = st.text_input(
            "Password",
            placeholder="Enter your password",
            help="Masukan password akun kamu."
        )
        
        col_login1, col_login2 = st.columns(2)
        
        with col_login1:
            if st.button("🚀 Login", type="primary", use_container_width=True):
                if username_input and password_input:
                    user_data = authenticate_user(username_input, password_input)
                    if user_data:
                        st.session_state.logged_in = True
                        st.session_state.current_user = user_data
                        st.success("✅ Login successful!")
                        st.rerun()
                    else:
                        st.error("❌ Invalid credentials. Please try again.")
                else:
                    st.warning("⚠️ Please fill in all fields.")
        
        st.markdown("---")
else:
    # Main Game Interface
    user_data = st.session_state.current_user
    
    # Header with logout
    col1, col2 = st.columns([3, 1])
    with col1:
        st.title(f"🎯 Quiz Game | Halo, {user_data.get('username')}!")
    
    # User stats
    users = load_users()  # Reload to get updated data
    current_user_data = None
    for user_info in users:
        if user_info.get('username') == user_data.get('username'):
            current_user_data = user_info
            break
    
    if current_user_data:
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown(f"### 🪙 Coins: {current_user_data.get('coins', 0)}")
        with col2:
            st.markdown(f"### 🏆 Highest Score: {current_user_data.get('highest_score', 0)}")
        with col3:
            user_role = current_user_data.get('user_role', 'murid')
            role_icon = "👩‍🏫" if user_role == "guru" else "👨‍🎓"
            st.markdown(f"### {role_icon} Role: {user_role.title()}")
    
    st.markdown("---")
    
    # Game setup or gameplay
    if not st.session_state.game_started:
        # Check for teacher mode
        if user_data.get('user_role') == 'guru':
            st.header("👩‍🏫 Teacher Panel")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("📝 Manage Questions", type="secondary", use_container_width=True):
                    st.session_state.show_question_manager = True
                    st.rerun()
            
            with col2:
                if st.button("🎮 Start Game", type="primary", use_container_width=True):
                    st.session_state.show_question_manager = False
            
            st.markdown("---")
            
            # Question Manager (same as before, but using load_quiz_data())
            if st.session_state.show_question_manager:
                st.subheader("📚 Question Manager")
                
                # Reload quiz data to get latest changes
                current_quiz_data = load_quiz_data()
                
                # Tab selection
                tab1, tab2, tab3 = st.tabs(["➕ Add Questions", "✏️ Edit Questions", "🗑️ Delete Questions"])
                
                with tab1:
                    st.subheader("➕ Add New Question")
                    
                    # Subject selection or creation
                    existing_subjects = list(current_quiz_data.keys())
                    subject_option = st.radio("Choose subject option:", ["Existing Subject", "New Subject"])
                    
                    if subject_option == "Existing Subject":
                        if existing_subjects:
                            selected_subject = st.selectbox("Select Subject:", existing_subjects)
                        else:
                            st.warning("No existing subjects. Please create a new subject.")
                            selected_subject = None
                    else:
                        selected_subject = st.text_input("New Subject Name:")
                    
                    if selected_subject:
                        new_question = st.text_area("Question:", placeholder="Enter your question here...")
                        new_answer = st.text_input("Correct Answer:", placeholder="Enter the correct answer...")
                        
                        st.write("**Options (4 required):**")
                        col1, col2 = st.columns(2)
                        with col1:
                            option1 = st.text_input("Option 1:", key="opt1")
                            option2 = st.text_input("Option 2:", key="opt2")
                        with col2:
                            option3 = st.text_input("Option 3:", key="opt3")
                            option4 = st.text_input("Option 4:", key="opt4")
                        
                        if st.button("➕ Add Question", type="primary"):
                            if new_question and new_answer and option1 and option2 and option3 and option4:
                                options = [option1, option2, option3, option4]
                                
                                # Check if correct answer is in options
                                if new_answer in options:
                                    new_q = {
                                        "q": new_question,
                                        "a": new_answer,
                                        "options": options
                                    }
                                    
                                    # Add to quiz data
                                    if selected_subject not in current_quiz_data:
                                        current_quiz_data[selected_subject] = []
                                    
                                    current_quiz_data[selected_subject].append(new_q)
                                    save_quiz_data(current_quiz_data)
                                    
                                    st.success(f"✅ Question added to {selected_subject}!")
                                    st.rerun()
                                else:
                                    st.error("❌ Correct answer must match exactly one of the options!")
                            else:
                                st.error("❌ Please fill in all fields!")
                
                st.markdown("---")
                if st.button("🔙 Back to Game Setup", type="primary"):
                    st.session_state.show_question_manager = False
                    st.rerun()
            
            # Only show game setup if not managing questions
            if not st.session_state.show_question_manager:
                st.header("🎮 Game Setup")
        else:
            st.header("🎮 Setup Game")
        
        # Game setup form (shown for both roles when not managing questions)
        if not st.session_state.show_question_manager:
            # Reload quiz data to ensure we have the latest questions
            current_quiz_data = load_quiz_data()
            
            if not current_quiz_data:
                st.error("❌ No quiz data available! Please add some questions first.")
                if user_data.get('user_role') == 'guru':
                    st.info("👩‍🏫 Use the 'Manage Questions' button above to add questions.")
            else:
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.subheader("📚 Pilih Mata Pelajaran")
                    subject = st.selectbox("Mata Pelajaran:", list(current_quiz_data.keys()))
                    st.session_state.selected_subject = subject
                
                with col2:
                    st.subheader("⚡ Tingkat Kesulitan")
                    difficulty = st.selectbox("Tingkat Kesulitan:", ["Easy", "Medium", "Hard"])
                    st.session_state.selected_difficulty = difficulty
                    
                    hearts_info = {
                        "Easy": "💚 5 Hearts",
                        "Medium": "💛 3 Hearts", 
                        "Hard": "❤️ 1 Heart"
                    }
                    st.info(f"**{difficulty}**: {hearts_info[difficulty]}")
                
                with col3:
                    st.subheader("🎯 Jumlah Pertanyaan")
                    max_questions = len(current_quiz_data.get(subject, []))
                    if max_questions > 0:
                        question_limit = st.number_input(
                            "Berapa pertanyaan?", 
                            min_value=1, 
                            max_value=min(20, max_questions), 
                            value=min(5, max_questions), 
                            step=1
                        )
                        st.session_state.question_limit = question_limit
                        st.info(f"**Target**: Jawab {question_limit} soal untuk menang!")
                        st.info(f"📊 Available: {max_questions} questions")
                    else:
                        st.error("❌ No questions available for this subject!")
                
                st.markdown("---")
                if current_quiz_data.get(subject) and len(current_quiz_data[subject]) > 0:
                    if st.button("🚀 Mulai Game", type="primary", use_container_width=True):
                        st.session_state.game_started = True
                        st.session_state.hearts = get_hearts_by_difficulty(difficulty)
                        st.session_state.current_question = get_random_question(subject)
                        st.rerun()
                else:
                    st.error("❌ Cannot start game - no questions available for selected subject!")

    else:
        # Game interface
        if not st.session_state.game_over and not st.session_state.victory:
            # Display game stats
            col1, col2, col3, col4, col5 = st.columns(5)
            with col1:
                st.metric("❤️ Hearts", st.session_state.hearts)
            with col2:
                st.metric("🏆 Current Score", st.session_state.score)
            with col3:
                st.metric("📚 Subject", st.session_state.selected_subject)
            with col4:
                st.metric("⚡ Difficulty", st.session_state.selected_difficulty)
            with col5:
                st.metric("🎯 Progress", f"{st.session_state.questions_answered}/{st.session_state.question_limit}")
            
            # Display active effects
            active_effects = []
            if st.session_state.score_boost_remaining > 0:
                active_effects.append(f"⭐ Score Boost ({st.session_state.score_boost_remaining} left)")
            if st.session_state.lucky_charm_active:
                active_effects.append("🍀 Lucky Charm Active")
            if st.session_state.coin_rain_remaining > 0:
                active_effects.append(f"💰 Coin Rain ({st.session_state.coin_rain_remaining} left)")
            if st.session_state.double_trouble_next:
                active_effects.append("⚡ Double Trouble Next")
            if st.session_state.skip_next_question:
                active_effects.append("🛡️ Skip Next Question")
            if st.session_state.confusion_next:
                active_effects.append("🌀 Confusion Next")
            
            if active_effects:
                st.info("🎪 Active Effects: " + " | ".join(active_effects))
            
            st.markdown("---")
            
            # Display current question
            if st.session_state.current_question:
                st.subheader("❓ Pertanyaan")
                st.write(f"**{st.session_state.current_question['q']}**")
                
                # Display feedback message if answer was submitted
                if st.session_state.feedback_message:
                    if "Benar" in st.session_state.feedback_message:
                        st.success(st.session_state.feedback_message)
                    else:
                        st.error(st.session_state.feedback_message)
                
                # Display crate message if available
                if st.session_state.crate_message:
                    if any(word in st.session_state.crate_message for word in ["Boost", "restored", "Skip", "Lucky", "Rain", "warp"]):
                        st.success(st.session_state.crate_message)
                    elif any(word in st.session_state.crate_message for word in ["Loss", "lost", "Disaster", "Confusion", "failed"]):
                        st.error(st.session_state.crate_message)
                    else:
                        st.info(st.session_state.crate_message)
                
                # Answer options
                if not st.session_state.answer_submitted:
                    st.subheader("🎯 Pilih Jawaban")
                    selected_answer = st.radio(
                        "Jawaban:",
                        st.session_state.current_question['options'],
                        key="answer_radio"
                    )
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button("✅ Submit Jawaban", type="primary", use_container_width=True):
                            check_answer(selected_answer, st.session_state.current_question['a'])
                            st.session_state.answer_submitted = True
                            st.rerun()
                    
                    with col2:
                        if st.button("🔄 Reset Game", use_container_width=True):
                            reset_game()
                            st.rerun()
                
                else:
                    # Show next question button
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button("➡️ Pertanyaan Selanjutnya", type="primary", use_container_width=True):
                            if not st.session_state.game_over and not st.session_state.victory:
                                st.session_state.current_question = get_random_question(st.session_state.selected_subject)
                                st.session_state.answer_submitted = False
                                st.session_state.feedback_message = ""
                                st.session_state.crate_message = ""
                                st.session_state.show_crate = False
                                st.rerun()
                    
                    with col2:
                        if st.button("🔄 Reset Game", use_container_width=True):
                            reset_game()
                            st.rerun()
        elif st.session_state.victory:
            # Victory screen
            st.header("🎉 Victory!")
            st.success(f"🏆 Selamat! Kamu berhasil menjawab {st.session_state.question_limit} soal dengan benar!")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("🏆 Final Score", st.session_state.score)
            with col2:
                st.metric("📚 Subject", st.session_state.selected_subject)
            with col3:
                users = load_users()
                current_user_data = None
                for user_info in users:
                    if user_info.get('username') == user_data.get('username'):
                        current_user_data = user_info
                        break
                if current_user_data:
                    st.metric("🏆 Highest Score", current_user_data.get('highest_score', 0))
            
            st.markdown("---")
            
            if st.button("🔄 Main Lagi", type="primary", use_container_width=True):
                reset_game()
                st.rerun()
        
        else:
            # Game over screen
            st.header("🎮 Game Over!")
            st.error(f"💔 Kamu kehabisan hearts! Game berakhir.")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("🏆 Final Score", st.session_state.score)
            with col2:
                st.metric("📚 Subject", st.session_state.selected_subject)
            with col3:
                st.metric("🎯 Questions Answered", f"{st.session_state.questions_answered}/{st.session_state.question_limit}")
            
            st.markdown("---")
            
            if st.button("🔄 Main Lagi", type="primary", use_container_width=True):
                reset_game()
                st.rerun()

    # Sidebar with instructions
    with st.sidebar: 
        st.header("Login sebagai:")
        st.code(user_data.get('username'))
        st.markdown("---")
        st.header("📋 Cara Bermain")
        st.markdown("""
        **🎯 Tujuan:** Jawab semua soal untuk menang!
        
        **⚡ Tingkat Kesulitan:**
        - **Easy**: 5 hearts
        - **Medium**: 3 hearts  
        - **Hard**: 1 heart
        
        **🎮 Aturan:**
        - ✅ Jawaban benar = +10 poin, +2 coins
        - ❌ Jawaban salah = -1 heart
        - 💔 Hearts = 0 → Game Over
        - 🏆 Jawab semua soal = Victory!
        
        **📦 Crate System:**
        - Every 5 questions = Random crate!
        - 12 different effects (buffs & debuffs)
        
        **💾 Progress Saved:**
        - Highest score tracked permanently
        - Coins persist between sessions
        """)
        
        st.markdown("---")
        
        # Crate list
        st.subheader("📦 Available Crates")
        for crate in CRATES:
            color = "🟢" if crate["type"] == "buff" else "🔴" if crate["type"] == "debuff" else "🟡"
            st.markdown(f"{color} {crate['icon']} **{crate['name']}**: {crate['description']}")
        
        st.markdown("---")
        st.markdown("**🎮 Selamat bermain!**")
    if st.sidebar.button("🚪 Logout", type="secondary"):
        st.session_state.logged_in = False
        st.session_state.current_user = None
        reset_game()
        st.rerun()