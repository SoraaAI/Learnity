import streamlit as st
import json
import os
from PIL import Image

# MBTI character data with different coin costs
MBTI_CHARACTERS = {
    'INTJ': {'name': 'The Architect', 'cost': 100},
    'INTP': {'name': 'The Thinker', 'cost': 95},
    'ENTJ': {'name': 'The Commander', 'cost': 110},
    'ENTP': {'name': 'The Debater', 'cost': 85},
    'INFJ': {'name': 'The Advocate', 'cost': 120},
    'INFP': {'name': 'The Mediator', 'cost': 80},
    'ENFJ': {'name': 'The Protagonist', 'cost': 105},
    'ENFP': {'name': 'The Campaigner', 'cost': 75},
    'ISTJ': {'name': 'The Logistician', 'cost': 90},
    'ISFJ': {'name': 'The Protector', 'cost': 70},
    'ESTJ': {'name': 'The Executive', 'cost': 95},
    'ESFJ': {'name': 'The Consul', 'cost': 85},
    'ISTP': {'name': 'The Virtuoso', 'cost': 100},
    'ISFP': {'name': 'The Adventurer', 'cost': 80},
    'ESTP': {'name': 'The Entrepreneur', 'cost': 90},
    'ESFP': {'name': 'The Entertainer', 'cost': 75}
}

def load_user_data():
    """Load user data from JSON file"""
    try:
        with open('database/user_data.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        st.error("User data file not found!")
        return []

def save_user_data(data):
    """Save user data to JSON file"""
    try:
        os.makedirs('database', exist_ok=True)
        with open('database/user_data.json', 'w') as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        st.error(f"Error saving data: {e}")
        return False

def authenticate(username_or_userid, password):
    """Authenticate user based on username/userid and password"""
    users = load_user_data()
    for user in users:
        if (user['username'] == username_or_userid or user['userid'] == username_or_userid) and user['password'] == password:
            return user
    return None

def update_user_data(updated_user):
    """Update specific user data in the database"""
    users = load_user_data()
    for i, user in enumerate(users):
        if user['userid'] == updated_user['userid']:
            users[i] = updated_user
            break
    return save_user_data(users)

def load_character_image(mbti_type):
    """Load character image based on MBTI type"""
    try:
        image_path = f"image/char/{mbti_type}_char.png"
        if os.path.exists(image_path):
            return Image.open(image_path)
        else:
            # Create a placeholder if image doesn't exist
            return None
    except Exception:
        return None

def main():
    st.set_page_config(page_title="MBTI Character Shop", page_icon="🎭", layout="wide")
    st.markdown(
        """
        <style>
        div.stButton > button {
            width: 100%;
            padding: 10px;
            background-color: #0d6efd;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        div.stButton > button:hover {
            background-color: #0b5ed7;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        """
        <style>
        div.stButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }
        </style>
        """,
        unsafe_allow_html=True
    )
    
    # Initialize session state
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    if 'current_user' not in st.session_state:
        st.session_state.current_user = None

    # Login Page
    if not st.session_state.logged_in:
        # Center the title and subtitle
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.markdown("<h1 style='text-align: center;'>🎭 Character Shop</h1>", unsafe_allow_html=True)
            st.markdown("<h3 style='text-align: center;'>Please login to continue</h3>", unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            with st.form("login_form"):
                username_input = st.text_input("Username or User ID")
                password_input = st.text_input("Password")
                login_button = st.form_submit_button("Login", use_container_width=True)
                
                if login_button:
                    if username_input and password_input:
                        user = authenticate(username_input, password_input)
                        if user:
                            st.session_state.logged_in = True
                            st.session_state.current_user = user
                            st.success("Login successful!")
                            st.rerun()
                        else:
                            st.error("Invalid username/userid or password!")
                    else:
                        st.warning("Please fill in both fields!")

    # Main Application
    else:
        user = st.session_state.current_user
        
        # Header
        st.title("🎭 Character Shop")
        
        # User info sidebar
        with st.sidebar:
            st.markdown("### User Profile")
            st.markdown(f"**👤 Username:** {user['username']}")
            st.markdown(f"**🆔 User ID:** {user['userid']}")
            st.markdown(f"**👨‍🎓 Role:** {user['user_role'].title()}")
            st.markdown(f"**🪙 Coins:** {user['coins']}")
            st.markdown(f"**🎯 Highest Score:** {user['highest_score']}")
            st.markdown(f"**🎭 Current Character:** {user['mbti']}")
            
            if st.button("Logout", use_container_width=True):
                st.session_state.logged_in = False
                st.session_state.current_user = None
                st.rerun()

        # Parse owned characters
        owned_chars = user['owned_char'].split(',') if user['owned_char'] else []
        
        # Character Shop
        st.markdown("## 🛍️ Yuk, gunain koin kamu dengan membeli karakter baru disini!")
        st.markdown(f"**Your current coins: {user['coins']} 🪙**")
        
        # Create grid layout for characters with better alignment
        mbti_list = list(MBTI_CHARACTERS.keys())
        
        # Display characters in rows of 4 for better alignment
        for row in range(0, len(mbti_list), 4):
            cols = st.columns(4)
            row_chars = mbti_list[row:row+4]
            
            for i, mbti_type in enumerate(row_chars):
                char_info = MBTI_CHARACTERS[mbti_type]
                with cols[i]:
                    # Character card with consistent height
                    with st.container():
                        # st.markdown(f"### {mbti_type}")
                        st.markdown(f"**{char_info['name']}**")
                        
                        # Load and display character image with consistent sizing
                        char_image = load_character_image(mbti_type)
                        if char_image:
                            # Resize image to consistent dimensions
                            char_image = char_image.resize((150, 150), Image.Resampling.LANCZOS)
                            st.image(char_image, width=150)
                        else:
                            # Placeholder when image is not found with consistent height
                            st.markdown(
                                "<div style='height: 150px; width: 150px; background-color: #f0f0f0; "
                                "display: flex; align-items: center; justify-content: center; "
                                "border: 2px dashed #ccc; margin: 0 auto;'>"
                                "🖼️<br>Image not found</div>", 
                                unsafe_allow_html=True
                            )
                        
                        st.markdown(f"**Cost: {char_info['cost']} 🪙**")
                        
                        # Check if character is owned
                        is_owned = mbti_type in owned_chars
                        is_current = user['mbti'] == mbti_type
                        
                        if is_current:
                            st.success("✅ Currently Using")
                        elif is_owned:
                            if st.button(f"Use {mbti_type}", key=f"use_{mbti_type}", use_container_width=True):
                                # Update current character
                                user['mbti'] = mbti_type
                                if update_user_data(user):
                                    st.session_state.current_user = user
                                    st.success(f"Now using {mbti_type}!")
                                    st.rerun()
                                else:
                                    st.error("Failed to update character!")
                        else:
                            # Check if user has enough coins
                            if user['coins'] >= char_info['cost']:
                                if st.button(f"Buy {mbti_type}", key=f"buy_{mbti_type}", use_container_width=True):
                                    # Purchase character
                                    user['coins'] -= char_info['cost']
                                    if user['owned_char']:
                                        user['owned_char'] += f",{mbti_type}"
                                    else:
                                        user['owned_char'] = mbti_type
                                    
                                    if update_user_data(user):
                                        st.session_state.current_user = user
                                        st.success(f"Successfully purchased {mbti_type}!")
                                        st.rerun()
                                    else:
                                        st.error("Failed to purchase character!")
                            else:
                                st.error(f"Need {char_info['cost'] - user['coins']} more coins")
                        
                        # Add some spacing at the bottom for consistency
                        st.markdown("<br>", unsafe_allow_html=True)

        # Owned Characters Section
        st.markdown("---")
        st.markdown("## 🎭 Your Characters")
        
        if owned_chars and owned_chars[0]:  # Check if user owns any characters
            st.markdown("**Characters you own:**")
            owned_cols = st.columns(min(len(owned_chars), 4))
            
            for i, char in enumerate(owned_chars):
                if char in MBTI_CHARACTERS:
                    with owned_cols[i % 4]:
                        st.markdown(f"{MBTI_CHARACTERS[char]['name']}")
                        if user['mbti'] == char:
                            st.success("✅ Currently Active")
        else:
            st.info("You don't own any characters yet. Purchase some from the shop above!")

if __name__ == "__main__":
    main()