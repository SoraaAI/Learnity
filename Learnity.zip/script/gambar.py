import streamlit as st
from PIL import Image
import google.generativeai as genai

# --- Judul dan Deskripsi Aplikasi ---
st.set_page_config(
    page_title="Analisis Foto dengan Gemini",
    page_icon="📸"
)
st.title("📸 Analisis Foto")
st.markdown("Unggah foto, berikan prompt Anda, dan biarkan AI menganalisisnya!")
st.markdown("---")

# --- Daftar Kunci API Gemini ---
# Script akan mencoba kunci API ini satu per satu.
API_KEYS = [
    "AIzaSyCW9PIEWhKwIEneXd4vum-2VokTed51hn4",
    "AIzaSyCs3IiV9eZP5MZ-LGY_IBD3M9u45Uo",
    "AIzaSyCpd_d7alhSm5-OFKbGv0Hu8QCWVex5-s4",
    "AIzaSyARZNLOvZV81F39V3pGsIJv2_Z9s0sBMl4",
    "AIzaSyB6UH8o9ojJGDKR5fRuooZ6qVBUhzZHcLM",
    "AIzaSyARU9APHRzRzPvWnGMmxvzFVt9FeFw8WIw",
    "AIzaSyDtiSp1xssRCPDvzP3bM_L9XcX5waUaYU8",
    "AIzaSyAolqcambI-LywE-sHrBzizyQHXBs37c3Q",
    "AIzaSyCslxIWJZk_9fFfEuW_jApl9aHymrmWBpQ",
    "AIzaSyCGxd6Amr7ofBhdIjE852B0mnBDyZ6jcKw"
]

def get_working_model():
    """
    Fungsi ini mengiterasi melalui daftar kunci API dan mengembalikan
    model yang berhasil dikonfigurasi.
    """
    for i, api_key in enumerate(API_KEYS):
        try:
            genai.configure(api_key=api_key)
            # Menggunakan genai.get_model() sebagai "pemeriksaan ringan"
            # Ini menguji validitas kunci API tanpa memanggil generate_content.
            genai.get_model('gemini-1.5-flash')
            # st.success(f"Kunci API berhasil dikonfigurasi (Kunci ke-{i+1}).")
            return genai.GenerativeModel('gemini-1.5-flash')
        except Exception as e:
            st.warning(f"Kunci API ke-{i+1} gagal: {e}. Mencoba kunci berikutnya...")
            continue
    st.error("Tidak ada kunci API yang berhasil dikonfigurasi. Mohon periksa kembali daftar kunci Anda.")
    return None

# Coba dapatkan model yang berfungsi saat aplikasi dimuat
model = get_working_model()

if model:
    # --- Antarmuka Pengguna (hanya ditampilkan jika ada model yang berfungsi) ---
    uploaded_file = st.file_uploader("Pilih sebuah gambar...", type=["jpg", "jpeg", "png"])
    if uploaded_file is not None:
        # Tampilkan gambar yang diunggah
        image = Image.open(uploaded_file)
        st.image(image, caption="Gambar yang Diunggah", use_column_width=True)

        # Masukan teks dari pengguna
        prompt_text = st.text_input(
            "Berikan prompt atau pertanyaan Anda tentang gambar ini:",
            value="Jelaskan gambar ini secara detail."
        )

        # Tombol untuk memulai analisis
        if st.button("Analisis Gambar"):
            if prompt_text:
                try:
                    with st.spinner("Sedang menganalisis gambar..."):
                        # Panggil API Gemini dengan prompt dan gambar
                        response = model.generate_content([prompt_text, image])

                        # Tampilkan hasil dari Gemini
                        st.markdown("---")
                        st.subheader("Hasil Analisis Gemini")
                        st.write(response.text)

                except Exception as e:
                    # Pesan kesalahan yang lebih umum jika masalah terjadi saat analisis
                    st.error(f"Terjadi kesalahan saat memanggil API Gemini. Ini bisa jadi masalah jaringan, batasan kuota, atau server Google. Mohon coba lagi nanti.")
                    st.exception(e) # Tampilkan detail error untuk debugging
            else:
                st.warning("Mohon berikan prompt atau pertanyaan untuk memulai analisis.")

