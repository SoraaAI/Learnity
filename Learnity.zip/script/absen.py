import streamlit as st
import json
import os
from datetime import datetime, date
import pandas as pd
from PIL import Image
import io
import threading
import time
import uuid
from werkzeug.utils import secure_filename
import base64

# Flask imports
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS

# Initialize session state
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'current_user' not in st.session_state:
    st.session_state.current_user = None
if 'flask_running' not in st.session_state:
    st.session_state.flask_running = False
if 'flask_config' not in st.session_state:
    st.session_state.flask_config = {
        'host': '0.0.0.0',
        'port': 5000,
        'debug': False,
        'max_file_size': 16  # MB
    }

# Flask App Setup
app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx'}
# Create necessary directories
os.makedirs('database', exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def setup_flask_config():
    """Setup Flask configuration from session state"""
    config = st.session_state.flask_config
    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
    app.config['MAX_CONTENT_LENGTH'] = config['max_file_size'] * 1024 * 1024
    
    # Create necessary directories
    os.makedirs('database', exist_ok=True)
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def load_json_file(filename):
    """Load JSON file, create if doesn't exist"""
    if not os.path.exists(filename):
        return []
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return []

def save_json_file(filename, data):
    """Save data to JSON file"""
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def initialize_data():
    """Initialize default data if files don't exist"""
    if not os.path.exists('database/user_data.json'):
        default_users = [
            {
                "username": "Sora",
                "userid": "123456789",
                "password": "123456",
                "user_role": "siswa",
                "mbti": "ISFJ",
                "highest_score": 50,
                "coins": 54
            },
            {
                "username": "Rika",
                "userid": "987654321",
                "password": "password",
                "user_role": "guru",
                "mbti": "INFP",
                "highest_score": 70,
                "coins": 30
            },
            {
                "username": "Satria",
                "userid": "387772535",
                "password": "Satria2",
                "user_role": "siswa",
                "mbti": "ISFJ",
                "highest_score": 0,
                "coins": 0
            },
            {
                "username": "Revan",
                "userid": "197476378",
                "password": "Tuakah",
                "user_role": "siswa",
                "mbti": "INFP",
                "highest_score": 0,
                "coins": 0
            }
        ]
        save_json_file('database/user_data.json', default_users)
    
    for filename in ['database/tugas_absen.json', 'database/assignments.json', 'database/submissions.json']:
        if not os.path.exists(filename):
            save_json_file(filename, [])

# Flask API Routes
# Tambahkan ini di bagian Flask API Routes
@app.route('/api/download_submission/<filename>', methods=['GET'])
def api_download_submission(filename):
    """Serve a file from the uploads folder"""
    try:
        return send_file(os.path.join(app.config['UPLOAD_FOLDER'], filename), as_attachment=True)
    except FileNotFoundError:
        return jsonify({'success': False, 'message': 'File not found'}), 404

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'timestamp': datetime.now().isoformat()})

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.json
    identifier = data.get('identifier')
    password = data.get('password')
    
    users = load_json_file('database/user_data.json')
    for user in users:
        if (user['username'] == identifier or user['userid'] == identifier) and user['password'] == password:
            return jsonify({'success': True, 'user': user})
    
    return jsonify({'success': False, 'message': 'Invalid credentials'}), 401

@app.route('/api/attendance', methods=['POST'])
def api_mark_attendance():
    data = request.json
    userid = data.get('userid')
    username = data.get('username')
    
    attendance_data = load_json_file('database/tugas_absen.json')
    today = date.today().isoformat()
    
    for record in attendance_data:
        if record['userid'] == userid and record['date'] == today:
            return jsonify({'success': False, 'message': 'Already marked attendance today'})
    
    new_record = {
        'userid': userid,
        'username': username,
        'date': today,
        'timestamp': datetime.now().isoformat()
    }
    attendance_data.append(new_record)
    save_json_file('database/tugas_absen.json', attendance_data)
    
    return jsonify({'success': True, 'message': 'Attendance marked successfully'})

@app.route('/api/attendance', methods=['GET'])
def api_get_attendance():
    attendance_data = load_json_file('database/tugas_absen.json')
    return jsonify(attendance_data)

@app.route('/api/assignments', methods=['GET'])
def api_get_assignments():
    assignments = load_json_file('database/assignments.json')
    return jsonify(assignments)

@app.route('/api/assignments', methods=['POST'])
def api_add_assignment():
    data = request.json
    assignments = load_json_file('database/assignments.json')
    
    new_assignment = {
        'id': len(assignments) + 1,
        'title': data.get('title'),
        'description': data.get('description'),
        'due_date': data.get('due_date'),
        'created_by': data.get('created_by'),
        'created_at': datetime.now().isoformat()
    }
    
    assignments.append(new_assignment)
    save_json_file('database/assignments.json', assignments)
    
    return jsonify({'success': True, 'assignment': new_assignment})

@app.route('/api/submissions', methods=['POST'])
def api_submit_assignment():
    try:
        file_data = None
        if 'file' in request.files:
            file = request.files['file']
            if file and file.filename != '' and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                unique_filename = f"{uuid.uuid4()}_{filename}"
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
                file.save(file_path)
                
                file_data = {
                    'filename': filename,
                    'stored_filename': unique_filename,
                    'size': os.path.getsize(file_path),
                    'type': file.content_type
                }
        
        assignment_id = int(request.form.get('assignment_id'))
        userid = request.form.get('userid')
        username = request.form.get('username')
        submission_text = request.form.get('submission_text')
        
        submissions = load_json_file('database/submissions.json')
        
        new_submission = {
            'id': len(submissions) + 1,
            'assignment_id': assignment_id,
            'userid': userid,
            'username': username,
            'submission_text': submission_text,
            'submitted_at': datetime.now().isoformat(),
            'file_data': file_data
        }
        
        submissions.append(new_submission)
        save_json_file('database/submissions.json', submissions)
        
        return jsonify({'success': True, 'submission': new_submission})
    
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Streamlit Helper Functions
def login_user(identifier, password):
    """Login user with username/userid and password"""
    users = load_json_file('database/user_data.json')
    for user in users:
        if (user['username'] == identifier or user['userid'] == identifier) and user['password'] == password:
            return user
    return None

def mark_attendance(userid, username):
    """Mark attendance for today"""
    attendance_data = load_json_file('database/tugas_absen.json')
    today = date.today().isoformat()
    
    for record in attendance_data:
        if record['userid'] == userid and record['date'] == today:
            return False, "Sudah absen hari ini!"
    
    new_record = {
        'userid': userid,
        'username': username,
        'date': today,
        'timestamp': datetime.now().isoformat()
    }
    attendance_data.append(new_record)
    save_json_file('database/tugas_absen.json', attendance_data)
    return True, "Absensi berhasil!"

def get_attendance_data():
    """Get all attendance data"""
    return load_json_file('database/tugas_absen.json')

def get_assignments():
    """Get all assignments"""
    return load_json_file('database/assignments.json')

def add_assignment(title, description, due_date, created_by):
    """Add new assignment"""
    assignments = load_json_file('database/assignments.json')
    new_assignment = {
        'id': len(assignments) + 1,
        'title': title,
        'description': description,
        'due_date': due_date,
        'created_by': created_by,
        'created_at': datetime.now().isoformat()
    }
    assignments.append(new_assignment)
    save_json_file('database/assignments.json', assignments)
    return new_assignment

# Ubah fungsi ini
def submit_assignment(assignment_id, userid, username, submission_text, uploaded_file=None):
    """Submit assignment, saving the file to disk and its reference to json"""
    submissions = load_json_file('database/submissions.json')
    
    file_data = None
    if uploaded_file:
        # Save the file to the uploads folder
        filename = secure_filename(uploaded_file.name)
        unique_filename = f"{uuid.uuid4()}_{filename}"
        file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
        
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        file_data = {
            'filename': filename,
            'stored_filename': unique_filename,
            'size': uploaded_file.size,
            'type': uploaded_file.type
        }
        
    new_submission = {
        'id': len(submissions) + 1,
        'assignment_id': assignment_id,
        'userid': userid,
        'username': username,
        'submission_text': submission_text,
        'submitted_at': datetime.now().isoformat(),
        'file_data': file_data
    }
    submissions.append(new_submission)
    save_json_file('database/submissions.json', submissions)
    return new_submission

def get_user_submissions(userid):
    """Get submissions by user"""
    submissions = load_json_file('database/submissions.json')
    return [s for s in submissions if s['userid'] == userid]

def get_assignment_submissions(assignment_id):
    """Get all submissions for an assignment"""
    submissions = load_json_file('database/submissions.json')
    return [s for s in submissions if s['assignment_id'] == assignment_id]

def run_flask_server():
    """Run Flask server in background"""
    if not st.session_state.flask_running:
        try:
            setup_flask_config()
            initialize_data()
            config = st.session_state.flask_config
            app.run(
                host=config['host'], 
                port=config['port'], 
                debug=config['debug'],
                use_reloader=False,
                threaded=True
            )
        except Exception as e:
            st.session_state.flask_running = False
            st.error(f"Flask server error: {e}")

def start_flask_background():
    """Start Flask server in background thread"""
    if not st.session_state.flask_running:
        flask_thread = threading.Thread(target=run_flask_server, daemon=True)
        flask_thread.start()
        st.session_state.flask_running = True
        time.sleep(2)  # Give server time to start

# Streamlit UI
st.set_page_config(
    page_title="School Management System",
    page_icon="🎓",
    layout="wide"
)

# Sidebar
with st.sidebar:
    st.title("🎓 School System")
    
    # Flask Configuration
    with st.expander("⚙️ Flask Configuration", expanded=False):
        st.subheader("Server Settings")
        
        host = st.text_input("Host", value=st.session_state.flask_config['host'])
        port = st.number_input("Port", value=st.session_state.flask_config['port'], min_value=1000, max_value=9999)
        debug = st.checkbox("Debug Mode", value=st.session_state.flask_config['debug'])
        max_file_size = st.slider("Max File Size (MB)", 1, 100, st.session_state.flask_config['max_file_size'])
        
        if st.button("Update Flask Config"):
            st.session_state.flask_config = {
                'host': host,
                'port': port,
                'debug': debug,
                'max_file_size': max_file_size
            }
            st.success("Configuration updated!")
        
        # Flask Server Control
        st.subheader("Server Control")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🚀 Start Flask"):
                if not st.session_state.flask_running:
                    start_flask_background()
                    st.success("Flask server starting...")
                else:
                    st.warning("Flask already running!")
        
        with col2:
            if st.button("🛑 Stop Flask"):
                st.session_state.flask_running = False
                st.info("Flask server stopped")
        
        # Server Status
        status_color = "🟢" if st.session_state.flask_running else "🔴"
        st.write(f"Status: {status_color} {'Running' if st.session_state.flask_running else 'Stopped'}")
        
        if st.session_state.flask_running:
            config = st.session_state.flask_config
            st.code(f"API URL: http://{config['host']}:{config['port']}")
    
    st.markdown("---")
    
    # Login Section
    st.title("🔐 Login")
    
    if not st.session_state.logged_in:
        identifier = st.text_input("Username atau User ID")
        password = st.text_input("Password", type="password")
        
        if st.button("Login"):
            user = login_user(identifier, password)
            if user:
                st.session_state.logged_in = True
                st.session_state.current_user = user
                st.success(f"Welcome, {user['username']}!")
                st.rerun()
            else:
                st.error("Username/ID atau password salah!")
    else:
        user = st.session_state.current_user
        st.success(f"Logged in as: {user['username']}")
        st.write(f"Role: {user['user_role']}")
        st.write(f"MBTI: {user['mbti_display']}")
        st.write(f"Coins: {user['coins']}")
        
        if st.button("Logout"):
            st.session_state.logged_in = False
            st.session_state.current_user = None
            st.rerun()

# Main App
if st.session_state.logged_in:
    user = st.session_state.current_user
    
    st.title(f"📚 Dashboard - {user['username']}")
    
    if user['user_role'] == 'siswa':
        # Student Dashboard
        tab1, tab2 = st.tabs(["📝 Absensi", "📋 Tugas"])
        
        with tab1:
            st.header("Absensi Harian")
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Absen Hari Ini")
                today = date.today().strftime("%d %B %Y")
                st.write(f"Tanggal: {today}")
                
                if st.button("✅ Absen Sekarang", type="primary"):
                    success, message = mark_attendance(user['userid'], user['username'])
                    if success:
                        st.success(message)
                    else:
                        st.warning(message)
            
            with col2:
                st.subheader("Riwayat Absensi Saya")
                attendance_data = get_attendance_data()
                my_attendance = [a for a in attendance_data if a['userid'] == user['userid']]
                
                if my_attendance:
                    df = pd.DataFrame(my_attendance)
                    df['date'] = pd.to_datetime(df['date']).dt.strftime('%d %B %Y')
                    st.dataframe(df[['date', 'timestamp']], use_container_width=True)
                else:
                    st.info("Belum ada riwayat absensi")
        
        with tab2:
            st.header("Tugas & Assignments")
            
            assignments = get_assignments()
            user_submissions = get_user_submissions(user['userid'])
            submitted_ids = [s['assignment_id'] for s in user_submissions]
            
            for assignment in assignments:
                with st.expander(f"📄 {assignment['title']} - Due: {assignment['due_date']}"):
                    st.write(f"**Deskripsi:** {assignment['description']}")
                    st.write(f"**Dibuat oleh:** {assignment['created_by']}")
                    
                    if assignment['id'] in submitted_ids:
                        st.success("✅ Sudah dikumpulkan")
                        submission = next(s for s in user_submissions if s['assignment_id'] == assignment['id'])
                        st.write(f"**Jawaban:** {submission['submission_text']}")
                        st.write(f"**Dikumpulkan pada:** {submission['submitted_at']}")
                        if submission.get('file_data'):
                            st.write(f"**File:** {submission['file_data']['filename']}")
                    else:
                        st.warning("⏳ Belum dikumpulkan")
                        
                        with st.form(f"submit_{assignment['id']}"):
                            submission_text = st.text_area("Jawaban Tugas:", key=f"text_{assignment['id']}")
                            uploaded_file = st.file_uploader("Upload File (Opsional):", 
                                                           type=['pdf', 'doc', 'docx', 'jpg', 'png'], 
                                                           key=f"file_{assignment['id']}")
                            
                            # Ubah bagian ini di dasbor siswa (tab2)
                            if st.form_submit_button("Kumpulkan Tugas"):
                                if submission_text.strip():
                                    # Langsung kirim objek uploaded_file
                                    submit_assignment(assignment['id'], user['userid'], user['username'], submission_text, uploaded_file)
                                    st.success("Tugas berhasil dikumpulkan!")
                                    st.rerun()
                                else:
                                    st.error("Jawaban tidak boleh kosong!")
    
    elif user['user_role'] == 'guru':
        # Teacher Dashboard
        tab1, tab2, tab3 = st.tabs(["👥 Data Absensi", "📝 Kelola Tugas", "📊 Submission"])
        
        with tab1:
            st.header("Data Absensi Siswa")
            
            attendance_data = get_attendance_data()
            
            if attendance_data:
                df = pd.DataFrame(attendance_data)
                df['date'] = pd.to_datetime(df['date']).dt.strftime('%d %B %Y')
                
                col1, col2 = st.columns(2)
                with col1:
                    selected_date = st.date_input("Filter Tanggal:")
                with col2:
                    if st.button("Show All Dates"):
                        selected_date = None
                
                if selected_date:
                    filtered_df = df[df['date'] == selected_date.strftime('%d %B %Y')]
                else:
                    filtered_df = df
                
                st.dataframe(filtered_df, use_container_width=True)
                
                st.subheader("Statistik Absensi")
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Total Absensi", len(attendance_data))
                with col2:
                    unique_students = df['username'].nunique()
                    st.metric("Siswa Aktif", unique_students)
                with col3:
                    today_attendance = len([a for a in attendance_data if a['date'] == date.today().isoformat()])
                    st.metric("Absen Hari Ini", today_attendance)
            else:
                st.info("Belum ada data absensi")
        
        with tab2:
            st.header("Kelola Tugas")
            
            with st.expander("➕ Tambah Tugas Baru"):
                with st.form("add_assignment"):
                    title = st.text_input("Judul Tugas:")
                    description = st.text_area("Deskripsi Tugas:")
                    due_date = st.date_input("Deadline:")
                    
                    if st.form_submit_button("Tambah Tugas"):
                        if title and description:
                            add_assignment(title, description, due_date.isoformat(), user['username'])
                            st.success("Tugas berhasil ditambahkan!")
                            st.rerun()
                        else:
                            st.error("Judul dan deskripsi harus diisi!")
            
            st.subheader("Daftar Tugas")
            assignments = get_assignments()
            
            for assignment in assignments:
                with st.expander(f"📄 {assignment['title']}"):
                    st.write(f"**Deskripsi:** {assignment['description']}")
                    st.write(f"**Deadline:** {assignment['due_date']}")
                    st.write(f"**Dibuat pada:** {assignment['created_at']}")
                    
                    submissions = get_assignment_submissions(assignment['id'])
                    st.write(f"**Jumlah Submission:** {len(submissions)}")
        
        # Ubah di bagian `with tab3:`
        with tab3:
            st.header("Submission Tugas")
            
            assignments = get_assignments()
            
            for assignment in assignments:
                with st.expander(f"📄 {assignment['title']} - Submissions"):
                    submissions = get_assignment_submissions(assignment['id'])
                    
                    if submissions:
                        config = st.session_state.flask_config
                        api_url = f"http://{config['host']}:{config['port']}"
                        
                        for submission in submissions:
                            st.write("---")
                            st.write(f"**Siswa:** {submission['username']}")
                            st.write(f"**Dikumpulkan:** {submission['submitted_at']}")
                            st.write(f"**Jawaban:** {submission['submission_text']}")
                            
                            if submission.get('file_data'):
                                # Cek apakah ada file yang disimpan dengan nama unik
                                stored_filename = submission['file_data'].get('stored_filename')
                                if stored_filename:
                                    download_url = f"{api_url}/api/download_submission/{stored_filename}"
                                    st.markdown(f"**File:** [{submission['file_data']['filename']}]({download_url})")
                                else:
                                    st.write(f"**File:** {submission['file_data']['filename']} (tidak dapat diunduh)")
                    else:
                        st.info("Belum ada submission untuk tugas ini")

else:
    st.title("🎓 Sistem Absensi & Tugas")
    st.write("Silakan login terlebih dahulu menggunakan sidebar.")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("### Selamat datang di page tugas dan absensi!:")
        st.code("""
👏👏👏👏
        """)
    
    with col2:
        st.write("### Flask Server Status:")
        if st.session_state.flask_running:
            st.success("🟢 Flask server is running")
            config = st.session_state.flask_config
            st.info(f"API available at: http://{config['host']}:{config['port']}")
        else:
            st.warning("🔴 Flask server is not running")
            st.info("Start the Flask server from the sidebar to enable API access")

# Auto-start Flask server
if not st.session_state.flask_running:
    with st.spinner("Starting Flask server..."):
        start_flask_background()