import streamlit as st
import os
import requests
import json
from pathlib import Path

# Configure page
st.set_page_config(
    page_title="Kuis Kepribadian Lengkap",
    page_icon="🧠",
    layout="wide"
)

# Button Style

st.markdown(
    """
    <style>
    div.stButton > button {
        width: 100%;
        padding: 10px;
        background-color: #0d6efd;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    div.stButton > button:hover {
        background-color: #0b5ed7;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <style>
    div.stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
    }
    </style>
    """,
    unsafe_allow_html=True
)

# Gemini API Configuration
GEMINI_API_KEY = "AIzaSyCslxIWJZk_9fFfEuW_jApl9aHymrmWBpQ"
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

def save_mbti_guess(mbti_result):
    """Save MBTI guess result to database/mbti_guess.txt"""
    try:
        os.makedirs('database', exist_ok=True)
        with open('database/mbti_guess.txt', 'w', encoding='utf-8') as f:
            f.write(mbti_result)
        
        return True, "MBTI guess berhasil disimpan!"
    except Exception as e:
        return False, f"Error menyimpan MBTI guess: {str(e)}"

def get_mbti_from_gemini(answers_text):
    try:
        if GEMINI_API_KEY == None:
            return False, "Error API."
        
        prompt = f"""Based on the following personality quiz answers, predict the user's MBTI type in exactly ONE WORD (just the 4-letter MBTI type like INTJ, ENFP, etc.):

{answers_text}

Please analyze the answers and respond with only the 4-letter MBTI type, nothing else."""

        payload = {
            "contents": [
                {
                    "parts": [
                        {
                            "text": prompt
                        }
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0.1,
                "maxOutputTokens": 10
            }
        }
        
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": GEMINI_API_KEY
        }
        
        # Add API key as parameter
        url_with_key = f"{GEMINI_API_URL}?key={GEMINI_API_KEY}"
        
        response = requests.post(url_with_key, json=payload, headers=headers, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            if 'candidates' in result and len(result['candidates']) > 0:
                mbti_type = result['candidates'][0]['content']['parts'][0]['text'].strip()
                # Validate MBTI format (4 letters)
                if len(mbti_type) == 4 and mbti_type.isalpha():
                    return True, mbti_type.upper()
                else:
                    return False, f"Invalid MBTI format received: {mbti_type}"
            else:
                return False, "No valid response from Gemini API"
        else:
            error_detail = ""
            try:
                error_response = response.json()
                error_detail = error_response.get('error', {}).get('message', 'Unknown error')
            except:
                error_detail = response.text
            return False, f"API Error {response.status_code}: {error_detail}"
            
    except requests.exceptions.Timeout:
        return False, "Request timeout - please try again"
    except requests.exceptions.ConnectionError:
        return False, "Connection error - please check your internet connection"
    except Exception as e:
        return False, f"Error calling Gemini API: {str(e)}"

def generate_answer_text(answers):
    """Generate formatted answer text"""
    answer_texts = {
        # Bagian I: Tes Kepribadian
        "q1": {"setuju": "Setuju", "tidak_setuju": "Tidak Setuju"},
        "q2": {"setuju": "Setuju", "tidak_setuju": "Tidak Setuju"},
        "q3": {"setuju": "Setuju", "tidak_setuju": "Tidak Setuju"},
        "q4": {"setuju": "Setuju", "tidak_setuju": "Tidak Setuju"},
        "q5": {"setuju": "Setuju", "tidak_setuju": "Tidak Setuju"},
        "q6": {"setuju": "Setuju", "tidak_setuju": "Tidak Setuju"},
        # Bagian II: Tes MBTI
        "q7": {"a": "Memulai membuka topik pembicaraan.", "b": "Menunggu orang membuka topik pembicaraan."},
        "q8": {"a": "Lebih semangat bekerja.", "b": "Merasa tertekan."},
        "q9": {"a": "Sedikit teman, namun sering bertemu.", "b": "Banyak teman walaupun jarang bertemu."},
        "q10": {"a": "'Badut' yang meramaikan setiap pertemuan.", "b": "'Tempat' curhat karena dianggap merupakan pendengar yang baik."},
        "q11": {"a": "Memilih untuk memendamnya.", "b": "Memilih untuk menceritakannya kepada teman-teman."},
        "q12": {"a": "Tidak terlalu peduli.", "b": "Selalu ingin jadi yang pertama kali tahu."},
        "q13": {"a": "Mudah memulai pembicaraan dan pembicaraan tersebut bertahan lama.", "b": "Sulit mencari topik pembicaraan dan biasanya pembicaraan tidak bertahan lama."},
        "q14": {"a": "Spontan dengan apa yang ingin dibicarakan.", "b": "Melatih apa yang ingin dibicarakan beberapa kali sebelum acara berlangsung."},
        "q15": {"a": "Memilih untuk pulang lebih awal karena merasa semakin lelah.", "b": "Bertahan sampai acara selesai karena merasa semakin bersemangat."},
        "q16": {"a": "Langsung mengomunikasikan kepada orang tersebut.", "b": "Tidak mengutarakan kepada orang tersebut karena merasa diri sendiri memiliki kekurangan."},
        "q17": {"a": "Intuisi", "b": "Fakta"},
        "q18": {"a": "\"Peluang Bisnis di Masa Depan\"", "b": "\"Cara Praktis Menjadi Kaya dalam Waktu 1 Bulan\""},
        # Bagian III: Pertanyaan Psikologi
        "q19": {
            "a": "Mencari kesalahan pada orang lain atau faktor eksternal untuk menjelaskan kegagalan tersebut.",
            "b": "Merenung dalam kesendirian, merasa sangat kecewa dan mempertanyakan kemampuan diri sendiri secara mendalam.",
            "c": "Menganalisis setiap langkah yang salah secara objektif untuk menemukan pelajaran berharga, meskipun terasa menyakitkan.",
            "d": "Segera bangkit dan mencari peluang baru, meskipun ada rasa takut akan terulangnya kegagalan."
        },
        "q20": {
            "a": "Kesempatan yang terlewatkan untuk belajar atau mengembangkan diri.",
            "b": "Hubungan yang rusak atau konflik yang belum terselesaikan.",
            "c": "Keputusan yang menyebabkan penyesalan mendalam atau rasa bersalah.",
            "d": "Momen ketidakberdayaan atau kerentanan yang membuat Anda merasa lemah."
        },
        "q21": {
            "a": "Jaminan dan pujian yang meyakinkan akan nilai diri Anda.",
            "b": "Ruang dan waktu untuk memproses emosi sendiri tanpa interupsi.",
            "c": "Dukungan praktis dan saran konkret untuk mengatasi masalah.",
            "d": "Pengertian dan penerimaan tanpa syarat, bahkan di saat terlemah Anda."
        },
        # Bagian IV: Pertanyaan Filosofi
        "q22": {
            "a": "Mencari kebahagiaan dan kepuasan pribadi.",
            "b": "Memberikan kontribusi positif bagi masyarakat dan lingkungan.",
            "c": "Mencapai potensi tertinggi diri sendiri dan terus belajar.",
            "d": "Menemukan makna dan kebenaran universal."
        },
        "q23": {
            "a": "Setiap individu menerima apa yang pantas mereka dapatkan berdasarkan usaha dan meritokrasi.",
            "b": "Sumber daya dan peluang didistribusikan secara merata untuk mengurangi ketimpangan.",
            "c": "Semua orang memiliki hak dan kesempatan yang sama di mata hukum, tanpa memandang latar belakang.",
            "d": "Sistem yang memastikan perlindungan bagi yang paling rentan dan memberikan kesempatan kedua bagi yang gagal."
        },
        "q24": {
            "a": "Kebenaran yang menyakitkan, karena saya percaya kejujuran adalah fondasi dari pertumbuhan.",
            "b": "Ilusi yang membahagiakan, jika itu melindungi diri saya atau orang lain dari penderitaan yang tidak perlu.",
            "c": "Mencari cara untuk menemukan kebenaran yang dapat diterima, meskipun itu berarti menghadapi kenyataan yang sulit.",
            "d": "Saya akan mempertimbangkan konteks dan dampaknya sebelum memutuskan."
        },
        "q25": {
            "a": "Sebagai alat untuk meningkatkan efisiensi dan kenyamanan hidup.",
            "b": "Sebagai pendorong evolusi kesadaran dan pemahaman manusia.",
            "c": "Sebagai potensi ancaman terhadap kemanusiaan jika tidak dikelola dengan bijak.",
            "d": "Sebagai sarana untuk menjembatani kesenjangan dan menciptakan dunia yang lebih inklusif."
        }
    }
    
    answer_text = "HASIL KUIS KEPRIBADIAN LENGKAP | Format: Pertanyaan: Jawaban_User\n"
    answer_text += "=====================================\n\n"
    
    answer_text += "BAGIAN I: TES KEPRIBADIAN\n"
    answer_text += f"1. Anda rutin mendapatkan teman baru: {answer_texts['q1'][answers['q1']]}\n\n"
    answer_text += f"2. Ide-ide kompleks dan baru lebih membuat Anda bersemangat: {answer_texts['q2'][answers['q2']]}\n\n"
    answer_text += f"3. Lebih terpengaruh oleh resonansi emosional daripada argumen faktual: {answer_texts['q3'][answers['q3']]}\n\n"
    answer_text += f"4. Ruang hidup dan kerja bersih dan terorganisir: {answer_texts['q4'][answers['q4']]}\n\n"
    answer_text += f"5. Tetap tenang dalam banyak tekanan: {answer_texts['q5'][answers['q5']]}\n\n"
    answer_text += f"6. Berjejaring dengan orang asing terasa menakutkan: {answer_texts['q6'][answers['q6']]}\n\n"
    
    answer_text += "BAGIAN II: TES MBTI\n"
    answer_text += f"1. Bertemu orang baru: {answer_texts['q7'][answers['q7']]}\n\n"
    answer_text += f"2. Pekerjaan menghadapi banyak orang baru: {answer_texts['q8'][answers['q8']]}\n\n"
    answer_text += f"3. Pilihan pertemanan: {answer_texts['q9'][answers['q9']]}\n\n"
    answer_text += f"4. Peran dalam kelompok: {answer_texts['q10'][answers['q10']]}\n\n"
    answer_text += f"5. Ketika ada masalah: {answer_texts['q11'][answers['q11']]}\n\n"
    answer_text += f"6. Ketika ada gosip baru: {answer_texts['q12'][answers['q12']]}\n\n"
    answer_text += f"7. Bertemu orang baru (pembicaraan): {answer_texts['q13'][answers['q13']]}\n\n"
    answer_text += f"8. Berbicara di depan publik: {answer_texts['q14'][answers['q14']]}\n\n"
    answer_text += f"9. Mendatangi pesta: {answer_texts['q15'][answers['q15']]}\n\n"
    answer_text += f"10. Tidak suka pada seseorang: {answer_texts['q16'][answers['q16']]}\n\n"
    answer_text += f"11. Yang lebih dipercayai: {answer_texts['q17'][answers['q17']]}\n\n"
    answer_text += f"12. Pilihan judul buku: {answer_texts['q18'][answers['q18']]}\n\n"
    
    answer_text += "BAGIAN III: PERTANYAAN PSIKOLOGI\n"
    answer_text += f"1. Reaksi terhadap kegagalan besar: {answer_texts['q19'][answers['q19']]}\n\n"
    answer_text += f"2. Hal yang ingin diubah dari masa lalu: {answer_texts['q20'][answers['q20']]}\n\n"
    answer_text += f"3. Kebutuhan saat merasa rentan: {answer_texts['q21'][answers['q21']]}\n\n"
    
    answer_text += "BAGIAN IV: PERTANYAAN FILOSOFI\n"
    answer_text += f"1. Tujuan utama kehidupan manusia: {answer_texts['q22'][answers['q22']]}\n\n"
    answer_text += f"2. Definisi keadilan dalam masyarakat: {answer_texts['q23'][answers['q23']]}\n\n"
    answer_text += f"3. Pilihan antara kebenaran dan ilusi: {answer_texts['q24'][answers['q24']]}\n\n"
    answer_text += f"4. Peran teknologi di masa depan: {answer_texts['q25'][answers['q25']]}\n"
    
    return answer_text

def main():
    # Initialize session state
    if 'submitted' not in st.session_state:
        st.session_state.submitted = False
    if 'answers_text' not in st.session_state:
        st.session_state.answers_text = ""
    if 'confirmed' not in st.session_state:
        st.session_state.confirmed = False
    if 'mbti_result' not in st.session_state:
        st.session_state.mbti_result = ""
    
    # Header
    st.title("🧠 Kuis Kepribadian Lengkap")
    st.markdown("*Temukan lebih dalam tentang kepribadian dan pandangan hidup Anda*")
    
    if not st.session_state.submitted:
        # Progress tracking
        progress_placeholder = st.empty()
        
        # Bagian I: Tes Kepribadian
        st.header("Bagian I: Tes Kepribadian")
        
        st.subheader("1. Anda rutin mendapatkan teman baru.")
        col1, col2 = st.columns(2)
        with col1:
            q1_setuju = st.button("Setuju", key="q1_setuju", use_container_width=True)
        with col2:
            q1_tidak = st.button("Tidak Setuju", key="q1_tidak", use_container_width=True)
        
        if 'q1' not in st.session_state:
            st.session_state.q1 = None
        if q1_setuju:
            st.session_state.q1 = "Setuju"
        elif q1_tidak:
            st.session_state.q1 = "Tidak Setuju"
        
        if st.session_state.q1:
            st.info(f"Dipilih: {st.session_state.q1}")
        
        st.subheader("2. Ide-ide kompleks dan baru lebih membuat Anda bersemangat daripada yang sederhana dan terang-terangan.")
        col1, col2 = st.columns(2)
        with col1:
            q2_setuju = st.button("Setuju", key="q2_setuju", use_container_width=True)
        with col2:
            q2_tidak = st.button("Tidak Setuju", key="q2_tidak", use_container_width=True)
        
        if 'q2' not in st.session_state:
            st.session_state.q2 = None
        if q2_setuju:
            st.session_state.q2 = "Setuju"
        elif q2_tidak:
            st.session_state.q2 = "Tidak Setuju"
        
        if st.session_state.q2:
            st.info(f"Dipilih: {st.session_state.q2}")
        
        st.subheader("3. Anda biasanya merasa lebih terpengaruh oleh apa yang beresonansi secara emosional dengan Anda daripada oleh argumen faktual.")
        col1, col2 = st.columns(2)
        with col1:
            q3_setuju = st.button("Setuju", key="q3_setuju", use_container_width=True)
        with col2:
            q3_tidak = st.button("Tidak Setuju", key="q3_tidak", use_container_width=True)
        
        if 'q3' not in st.session_state:
            st.session_state.q3 = None
        if q3_setuju:
            st.session_state.q3 = "Setuju"
        elif q3_tidak:
            st.session_state.q3 = "Tidak Setuju"
        
        if st.session_state.q3:
            st.info(f"Dipilih: {st.session_state.q3}")
        
        st.subheader("4. Ruang hidup dan kerja Anda bersih dan terorganisir.")
        col1, col2 = st.columns(2)
        with col1:
            q4_setuju = st.button("Setuju", key="q4_setuju", use_container_width=True)
        with col2:
            q4_tidak = st.button("Tidak Setuju", key="q4_tidak", use_container_width=True)
        
        if 'q4' not in st.session_state:
            st.session_state.q4 = None
        if q4_setuju:
            st.session_state.q4 = "Setuju"
        elif q4_tidak:
            st.session_state.q4 = "Tidak Setuju"
        
        if st.session_state.q4:
            st.info(f"Dipilih: {st.session_state.q4}")
        
        st.subheader("5. Anda biasanya tetap tenang sekalipun sedang dalam banyak tekanan.")
        col1, col2 = st.columns(2)
        with col1:
            q5_setuju = st.button("Setuju", key="q5_setuju", use_container_width=True)
        with col2:
            q5_tidak = st.button("Tidak Setuju", key="q5_tidak", use_container_width=True)
        
        if 'q5' not in st.session_state:
            st.session_state.q5 = None
        if q5_setuju:
            st.session_state.q5 = "Setuju"
        elif q5_tidak:
            st.session_state.q5 = "Tidak Setuju"
        
        if st.session_state.q5:
            st.info(f"Dipilih: {st.session_state.q5}")
        
        st.subheader("6. Anda merasa konsep berjejaring atau memperkenalkan diri Anda kepada orang asing sangat menakutkan.")
        col1, col2 = st.columns(2)
        with col1:
            q6_setuju = st.button("Setuju", key="q6_setuju", use_container_width=True)
        with col2:
            q6_tidak = st.button("Tidak Setuju", key="q6_tidak", use_container_width=True)
        
        if 'q6' not in st.session_state:
            st.session_state.q6 = None
        if q6_setuju:
            st.session_state.q6 = "Setuju"
        elif q6_tidak:
            st.session_state.q6 = "Tidak Setuju"
        
        if st.session_state.q6:
            st.info(f"Dipilih: {st.session_state.q6}")
        
        # Bagian II: Tes MBTI
        st.header("Bagian II: Tes MBTI")
        
        st.subheader("1. Ketika bertemu dengan orang baru kamu biasanya...")
        col1, col2 = st.columns(2)
        with col1:
            q7_a = st.button("Memulai membuka topik pembicaraan.", key="q7_a", use_container_width=True)
        with col2:
            q7_b = st.button("Menunggu orang membuka topik pembicaraan.", key="q7_b", use_container_width=True)
        
        if 'q7' not in st.session_state:
            st.session_state.q7 = None
        if q7_a:
            st.session_state.q7 = "Memulai membuka topik pembicaraan."
        elif q7_b:
            st.session_state.q7 = "Menunggu orang membuka topik pembicaraan."
        
        if st.session_state.q7:
            st.info(f"Dipilih: {st.session_state.q7}")
        
        st.subheader("2. Pekerjaan yang mengharuskan diri kamu menghadapi banyak orang baru membuat kamu...")
        col1, col2 = st.columns(2)
        with col1:
            q8_a = st.button("Lebih semangat bekerja.", key="q8_a", use_container_width=True)
        with col2:
            q8_b = st.button("Merasa tertekan.", key="q8_b", use_container_width=True)
        
        if 'q8' not in st.session_state:
            st.session_state.q8 = None
        if q8_a:
            st.session_state.q8 = "Lebih semangat bekerja."
        elif q8_b:
            st.session_state.q8 = "Merasa tertekan."
        
        if st.session_state.q8:
            st.info(f"Dipilih: {st.session_state.q8}")
        
        st.subheader("3. Mana yang lebih kamu pilih?")
        col1, col2 = st.columns(2)
        with col1:
            q9_a = st.button("Sedikit teman, namun sering bertemu.", key="q9_a", use_container_width=True)
        with col2:
            q9_b = st.button("Banyak teman walaupun jarang bertemu.", key="q9_b", use_container_width=True)
        
        if 'q9' not in st.session_state:
            st.session_state.q9 = None
        if q9_a:
            st.session_state.q9 = "Sedikit teman, namun sering bertemu."
        elif q9_b:
            st.session_state.q9 = "Banyak teman walaupun jarang bertemu."
        
        if st.session_state.q9:
            st.info(f"Dipilih: {st.session_state.q9}")
        
        st.subheader("4. Dalam kelompok pertemanan kamu, kamu adalah seorang...")
        col1, col2 = st.columns(2)
        with col1:
            q10_a = st.button("'Badut' yang meramaikan setiap pertemuan.", key="q10_a", use_container_width=True)
        with col2:
            q10_b = st.button("'Tempat' curhat karena dianggap merupakan pendengar yang baik.", key="q10_b", use_container_width=True)
        
        if 'q10' not in st.session_state:
            st.session_state.q10 = None
        if q10_a:
            st.session_state.q10 = "'Badut' yang meramaikan setiap pertemuan."
        elif q10_b:
            st.session_state.q10 = "'Tempat' curhat karena dianggap merupakan pendengar yang baik."
        
        if st.session_state.q10:
            st.info(f"Dipilih: {st.session_state.q10}")
        
        st.subheader("5. Ketika ada masalah biasanya kamu...")
        col1, col2 = st.columns(2)
        with col1:
            q11_a = st.button("Memilih untuk memendamnya.", key="q11_a", use_container_width=True)
        with col2:
            q11_b = st.button("Memilih untuk menceritakannya kepada teman-teman.", key="q11_b", use_container_width=True)
        
        if 'q11' not in st.session_state:
            st.session_state.q11 = None
        if q11_a:
            st.session_state.q11 = "Memilih untuk memendamnya."
        elif q11_b:
            st.session_state.q11 = "Memilih untuk menceritakannya kepada teman-teman."
        
        if st.session_state.q11:
            st.info(f"Dipilih: {st.session_state.q11}")
        
        st.subheader("6. Ketika ada gosip baru, kamu...")
        col1, col2 = st.columns(2)
        with col1:
            q12_a = st.button("Tidak terlalu peduli.", key="q12_a", use_container_width=True)
        with col2:
            q12_b = st.button("Selalu ingin jadi yang pertama kali tahu.", key="q12_b", use_container_width=True)
        
        if 'q12' not in st.session_state:
            st.session_state.q12 = None
        if q12_a:
            st.session_state.q12 = "Tidak terlalu peduli."
        elif q12_b:
            st.session_state.q12 = "Selalu ingin jadi yang pertama kali tahu."
        
        if st.session_state.q12:
            st.info(f"Dipilih: {st.session_state.q12}")
        
        st.subheader("7. Ketika bertemu orang baru, kamu biasanya...")
        col1, col2 = st.columns(2)
        with col1:
            q13_a = st.button("Mudah memulai pembicaraan dan pembicaraan tersebut bertahan lama.", key="q13_a", use_container_width=True)
        with col2:
            q13_b = st.button("Sulit mencari topik pembicaraan dan biasanya pembicaraan tidak bertahan lama.", key="q13_b", use_container_width=True)
        
        if 'q13' not in st.session_state:
            st.session_state.q13 = None
        if q13_a:
            st.session_state.q13 = "Mudah memulai pembicaraan dan pembicaraan tersebut bertahan lama."
        elif q13_b:
            st.session_state.q13 = "Sulit mencari topik pembicaraan dan biasanya pembicaraan tidak bertahan lama."
        
        if st.session_state.q13:
            st.info(f"Dipilih: {st.session_state.q13}")
        
        st.subheader("8. Ketika harus berbicara di depan publik, kamu biasanya...")
        col1, col2 = st.columns(2)
        with col1:
            q14_a = st.button("Spontan dengan apa yang ingin dibicarakan.", key="q14_a", use_container_width=True)
        with col2:
            q14_b = st.button("Melatih apa yang ingin dibicarakan beberapa kali sebelum acara berlangsung.", key="q14_b", use_container_width=True)
        
        if 'q14' not in st.session_state:
            st.session_state.q14 = None
        if q14_a:
            st.session_state.q14 = "Spontan dengan apa yang ingin dibicarakan."
        elif q14_b:
            st.session_state.q14 = "Melatih apa yang ingin dibicarakan beberapa kali sebelum acara berlangsung."
        
        if st.session_state.q14:
            st.info(f"Dipilih: {st.session_state.q14}")
        
        st.subheader("9. Ketika mendatangi pesta, kamu biasanya...")
        col1, col2 = st.columns(2)
        with col1:
            q15_a = st.button("Memilih untuk pulang lebih awal karena merasa semakin lelah.", key="q15_a", use_container_width=True)
        with col2:
            q15_b = st.button("Bertahan sampai acara selesai karena merasa semakin bersemangat.", key="q15_b", use_container_width=True)
        
        if 'q15' not in st.session_state:
            st.session_state.q15 = None
        if q15_a:
            st.session_state.q15 = "Memilih untuk pulang lebih awal karena merasa semakin lelah."
        elif q15_b:
            st.session_state.q15 = "Bertahan sampai acara selesai karena merasa semakin bersemangat."
        
        if st.session_state.q15:
            st.info(f"Dipilih: {st.session_state.q15}")
        
        st.subheader("10. Ketika tidak suka pada seseorang, kamu biasanya...")
        col1, col2 = st.columns(2)
        with col1:
            q16_a = st.button("Langsung mengomunikasikan kepada orang tersebut.", key="q16_a", use_container_width=True)
        with col2:
            q16_b = st.button("Tidak mengutarakan kepada orang tersebut karena merasa diri sendiri memiliki kekurangan.", key="q16_b", use_container_width=True)
        
        if 'q16' not in st.session_state:
            st.session_state.q16 = None
        if q16_a:
            st.session_state.q16 = "Langsung mengomunikasikan kepada orang tersebut."
        elif q16_b:
            st.session_state.q16 = "Tidak mengutarakan kepada orang tersebut karena merasa diri sendiri memiliki kekurangan."
        
        if st.session_state.q16:
            st.info(f"Dipilih: {st.session_state.q16}")
        
        st.subheader("11. Mana yang lebih kamu percayai?")
        col1, col2 = st.columns(2)
        with col1:
            q17_a = st.button("Intuisi", key="q17_a", use_container_width=True)
        with col2:
            q17_b = st.button("Fakta", key="q17_b", use_container_width=True)
        
        if 'q17' not in st.session_state:
            st.session_state.q17 = None
        if q17_a:
            st.session_state.q17 = "Intuisi"
        elif q17_b:
            st.session_state.q17 = "Fakta"
        
        if st.session_state.q17:
            st.info(f"Dipilih: {st.session_state.q17}")
        
        st.subheader("12. Jika sekarang kamu diminta untuk menulis buku, judul apa yang akan kamu pilih?")
        col1, col2 = st.columns(2)
        with col1:
            q18_a = st.button('"Peluang Bisnis di Masa Depan"', key="q18_a", use_container_width=True)
        with col2:
            q18_b = st.button('"Cara Praktis Menjadi Kaya dalam Waktu 1 Bulan"', key="q18_b", use_container_width=True)
        
        if 'q18' not in st.session_state:
            st.session_state.q18 = None
        if q18_a:
            st.session_state.q18 = '"Peluang Bisnis di Masa Depan"'
        elif q18_b:
            st.session_state.q18 = '"Cara Praktis Menjadi Kaya dalam Waktu 1 Bulan"'
        
        if st.session_state.q18:
            st.info(f"Dipilih: {st.session_state.q18}")
        
        # Bagian III: Pertanyaan Psikologi
        st.header("Bagian III: Pertanyaan Psikologi")
        
        st.subheader("1. Ketika dihadapkan pada kegagalan besar dalam suatu proyek yang sangat Anda impikan, reaksi pertama Anda adalah:")
        col1, col2 = st.columns(2)
        with col1:
            q19_a = st.button("Mencari kesalahan pada orang lain atau faktor eksternal untuk menjelaskan kegagalan tersebut.", key="q19_a", use_container_width=True)
            q19_c = st.button("Menganalisis setiap langkah yang salah secara objektif untuk menemukan pelajaran berharga, meskipun terasa menyakitkan.", key="q19_c", use_container_width=True)
        with col2:
            q19_b = st.button("Merenung dalam kesendirian, merasa sangat kecewa dan mempertanyakan kemampuan diri sendiri secara mendalam.", key="q19_b", use_container_width=True)
            q19_d = st.button("Segera bangkit dan mencari peluang baru, meskipun ada rasa takut akan terulangnya kegagalan.", key="q19_d", use_container_width=True)
        
        if 'q19' not in st.session_state:
            st.session_state.q19 = None
        if q19_a:
            st.session_state.q19 = "Mencari kesalahan pada orang lain atau faktor eksternal untuk menjelaskan kegagalan tersebut."
        elif q19_b:
            st.session_state.q19 = "Merenung dalam kesendirian, merasa sangat kecewa dan mempertanyakan kemampuan diri sendiri secara mendalam."
        elif q19_c:
            st.session_state.q19 = "Menganalisis setiap langkah yang salah secara objektif untuk menemukan pelajaran berharga, meskipun terasa menyakitkan."
        elif q19_d:
            st.session_state.q19 = "Segera bangkit dan mencari peluang baru, meskipun ada rasa takut akan terulangnya kegagalan."
        
        if st.session_state.q19:
            st.info(f"Dipilih: {st.session_state.q19}")
        
        st.subheader("2. Jika Anda memiliki kesempatan untuk mengubah satu hal tentang masa lalu Anda, tanpa mempertimbangkan dampaknya pada masa kini atau masa depan, apa yang akan Anda ubah?")
        col1, col2 = st.columns(2)
        with col1:
            q20_a = st.button("Kesempatan yang terlewatkan untuk belajar atau mengembangkan diri.", key="q20_a", use_container_width=True)
            q20_c = st.button("Keputusan yang menyebabkan penyesalan mendalam atau rasa bersalah.", key="q20_c", use_container_width=True)
        with col2:
            q20_b = st.button("Hubungan yang rusak atau konflik yang belum terselesaikan.", key="q20_b", use_container_width=True)
            q20_d = st.button("Momen ketidakberdayaan atau kerentanan yang membuat Anda merasa lemah.", key="q20_d", use_container_width=True)
        
        if 'q20' not in st.session_state:
            st.session_state.q20 = None
        if q20_a:
            st.session_state.q20 = "Kesempatan yang terlewatkan untuk belajar atau mengembangkan diri."
        elif q20_b:
            st.session_state.q20 = "Hubungan yang rusak atau konflik yang belum terselesaikan."
        elif q20_c:
            st.session_state.q20 = "Keputusan yang menyebabkan penyesalan mendalam atau rasa bersalah."
        elif q20_d:
            st.session_state.q20 = "Momen ketidakberdayaan atau kerentanan yang membuat Anda merasa lemah."
        
        if st.session_state.q20:
            st.info(f"Dipilih: {st.session_state.q20}")
        
        st.subheader("3. Ketika Anda merasa tidak aman atau rentan, apa yang paling Anda butuhkan dari orang-orang di sekitar Anda?")
        col1, col2 = st.columns(2)
        with col1:
            q21_a = st.button("Jaminan dan pujian yang meyakinkan akan nilai diri Anda.", key="q21_a", use_container_width=True)
            q21_c = st.button("Dukungan praktis dan saran konkret untuk mengatasi masalah.", key="q21_c", use_container_width=True)
        with col2:
            q21_b = st.button("Ruang dan waktu untuk memproses emosi sendiri tanpa interupsi.", key="q21_b", use_container_width=True)
            q21_d = st.button("Pengertian dan penerimaan tanpa syarat, bahkan di saat terlemah Anda.", key="q21_d", use_container_width=True)
        
        if 'q21' not in st.session_state:
            st.session_state.q21 = None
        if q21_a:
            st.session_state.q21 = "Jaminan dan pujian yang meyakinkan akan nilai diri Anda."
        elif q21_b:
            st.session_state.q21 = "Ruang dan waktu untuk memproses emosi sendiri tanpa interupsi."
        elif q21_c:
            st.session_state.q21 = "Dukungan praktis dan saran konkret untuk mengatasi masalah."
        elif q21_d:
            st.session_state.q21 = "Pengertian dan penerimaan tanpa syarat, bahkan di saat terlemah Anda."
        
        if st.session_state.q21:
            st.info(f"Dipilih: {st.session_state.q21}")
        
        # Bagian IV: Pertanyaan Filosofi
        st.header("Bagian IV: Pertanyaan Filosofi")
        
        st.subheader("1. Apa yang Anda yakini sebagai tujuan utama kehidupan manusia?")
        col1, col2 = st.columns(2)
        with col1:
            q22_a = st.button("Mencari kebahagiaan dan kepuasan pribadi.", key="q22_a", use_container_width=True)
            q22_c = st.button("Mencapai potensi tertinggi diri sendiri dan terus belajar.", key="q22_c", use_container_width=True)
        with col2:
            q22_b = st.button("Memberikan kontribusi positif bagi masyarakat dan lingkungan.", key="q22_b", use_container_width=True)
            q22_d = st.button("Menemukan makna dan kebenaran universal.", key="q22_d", use_container_width=True)
        
        if 'q22' not in st.session_state:
            st.session_state.q22 = None
        if q22_a:
            st.session_state.q22 = "Mencari kebahagiaan dan kepuasan pribadi."
        elif q22_b:
            st.session_state.q22 = "Memberikan kontribusi positif bagi masyarakat dan lingkungan."
        elif q22_c:
            st.session_state.q22 = "Mencapai potensi tertinggi diri sendiri dan terus belajar."
        elif q22_d:
            st.session_state.q22 = "Menemukan makna dan kebenaran universal."
        
        if st.session_state.q22:
            st.info(f"Dipilih: {st.session_state.q22}")
        
        st.subheader("2. Bagaimana Anda mendefinisikan \"keadilan\" dalam masyarakat?")
        col1, col2 = st.columns(2)
        with col1:
            q23_a = st.button("Setiap individu menerima apa yang pantas mereka dapatkan berdasarkan usaha dan meritokrasi.", key="q23_a", use_container_width=True)
            q23_c = st.button("Semua orang memiliki hak dan kesempatan yang sama di mata hukum, tanpa memandang latar belakang.", key="q23_c", use_container_width=True)
        with col2:
            q23_b = st.button("Sumber daya dan peluang didistribusikan secara merata untuk mengurangi ketimpangan.", key="q23_b", use_container_width=True)
            q23_d = st.button("Sistem yang memastikan perlindungan bagi yang paling rentan dan memberikan kesempatan kedua bagi yang gagal.", key="q23_d", use_container_width=True)
        
        if 'q23' not in st.session_state:
            st.session_state.q23 = None
        if q23_a:
            st.session_state.q23 = "Setiap individu menerima apa yang pantas mereka dapatkan berdasarkan usaha dan meritokrasi."
        elif q23_b:
            st.session_state.q23 = "Sumber daya dan peluang didistribusikan secara merata untuk mengurangi ketimpangan."
        elif q23_c:
            st.session_state.q23 = "Semua orang memiliki hak dan kesempatan yang sama di mata hukum, tanpa memandang latar belakang."
        elif q23_d:
            st.session_state.q23 = "Sistem yang memastikan perlindungan bagi yang paling rentan dan memberikan kesempatan kedua bagi yang gagal."
        
        if st.session_state.q23:
            st.info(f"Dipilih: {st.session_state.q23}")
        
        st.subheader("3. Jika Anda harus memilih antara kebenaran yang menyakitkan atau ilusi yang membahagiakan, mana yang akan Anda pilih?")
        col1, col2 = st.columns(2)
        with col1:
            q24_a = st.button("Kebenaran yang menyakitkan, karena saya percaya kejujuran adalah fondasi dari pertumbuhan.", key="q24_a", use_container_width=True)
            q24_c = st.button("Mencari cara untuk menemukan kebenaran yang dapat diterima, meskipun itu berarti menghadapi kenyataan yang sulit.", key="q24_c", use_container_width=True)
        with col2:
            q24_b = st.button("Ilusi yang membahagiakan, jika itu melindungi diri saya atau orang lain dari penderitaan yang tidak perlu.", key="q24_b", use_container_width=True)
            q24_d = st.button("Saya akan mempertimbangkan konteks dan dampaknya sebelum memutuskan.", key="q24_d", use_container_width=True)
        
        if 'q24' not in st.session_state:
            st.session_state.q24 = None
        if q24_a:
            st.session_state.q24 = "Kebenaran yang menyakitkan, karena saya percaya kejujuran adalah fondasi dari pertumbuhan."
        elif q24_b:
            st.session_state.q24 = "Ilusi yang membahagiakan, jika itu melindungi diri saya atau orang lain dari penderitaan yang tidak perlu."
        elif q24_c:
            st.session_state.q24 = "Mencari cara untuk menemukan kebenaran yang dapat diterima, meskipun itu berarti menghadapi kenyataan yang sulit."
        elif q24_d:
            st.session_state.q24 = "Saya akan mempertimbangkan konteks dan dampaknya sebelum memutuskan."
        
        if st.session_state.q24:
            st.info(f"Dipilih: {st.session_state.q24}")
        
        st.subheader("4. Menurut Anda, apa peran utama teknologi dalam kehidupan manusia di masa depan?")
        col1, col2 = st.columns(2)
        with col1:
            q25_a = st.button("Sebagai alat untuk meningkatkan efisiensi dan kenyamanan hidup.", key="q25_a", use_container_width=True)
            q25_c = st.button("Sebagai potensi ancaman terhadap kemanusiaan jika tidak dikelola dengan bijak.", key="q25_c", use_container_width=True)
        with col2:
            q25_b = st.button("Sebagai pendorong evolusi kesadaran dan pemahaman manusia.", key="q25_b", use_container_width=True)
            q25_d = st.button("Sebagai sarana untuk menjembatani kesenjangan dan menciptakan dunia yang lebih inklusif.", key="q25_d", use_container_width=True)
        
        if 'q25' not in st.session_state:
            st.session_state.q25 = None
        if q25_a:
            st.session_state.q25 = "Sebagai alat untuk meningkatkan efisiensi dan kenyamanan hidup."
        elif q25_b:
            st.session_state.q25 = "Sebagai pendorong evolusi kesadaran dan pemahaman manusia."
        elif q25_c:
            st.session_state.q25 = "Sebagai potensi ancaman terhadap kemanusiaan jika tidak dikelola dengan bijak."
        elif q25_d:
            st.session_state.q25 = "Sebagai sarana untuk menjembatani kesenjangan dan menciptakan dunia yang lebih inklusif."
        
        if st.session_state.q25:
            st.info(f"Dipilih: {st.session_state.q25}")
        
        # Calculate and show progress
        all_answers = [st.session_state.get(f'q{i}') for i in range(1, 26)]
        answered_count = sum(1 for answer in all_answers if answer is not None)
        progress = answered_count / 25
        
        progress_placeholder.progress(progress, text=f"Progress: {answered_count}/25 pertanyaan dijawab")
        
        st.divider()
        
        # Submit button
        if st.button("Kirim Jawaban", type="primary", use_container_width=True):
            # Check if all questions are answered
            if answered_count < 25:
                st.error("Mohon jawab semua pertanyaan sebelum mengirim.")
            else:
                # Convert answers to required format
                answers = {
                    'q1': 'setuju' if st.session_state.q1 == 'Setuju' else 'tidak_setuju',
                    'q2': 'setuju' if st.session_state.q2 == 'Setuju' else 'tidak_setuju',
                    'q3': 'setuju' if st.session_state.q3 == 'Setuju' else 'tidak_setuju',
                    'q4': 'setuju' if st.session_state.q4 == 'Setuju' else 'tidak_setuju',
                    'q5': 'setuju' if st.session_state.q5 == 'Setuju' else 'tidak_setuju',
                    'q6': 'setuju' if st.session_state.q6 == 'Setuju' else 'tidak_setuju',
                    'q7': 'a' if st.session_state.q7 == 'Memulai membuka topik pembicaraan.' else 'b',
                    'q8': 'a' if st.session_state.q8 == 'Lebih semangat bekerja.' else 'b',
                    'q9': 'a' if st.session_state.q9 == 'Sedikit teman, namun sering bertemu.' else 'b',
                    'q10': 'a' if st.session_state.q10 == "'Badut' yang meramaikan setiap pertemuan." else 'b',
                    'q11': 'a' if st.session_state.q11 == 'Memilih untuk memendamnya.' else 'b',
                    'q12': 'a' if st.session_state.q12 == 'Tidak terlalu peduli.' else 'b',
                    'q13': 'a' if st.session_state.q13 == 'Mudah memulai pembicaraan dan pembicaraan tersebut bertahan lama.' else 'b',
                    'q14': 'a' if st.session_state.q14 == 'Spontan dengan apa yang ingin dibicarakan.' else 'b',
                    'q15': 'a' if st.session_state.q15 == 'Memilih untuk pulang lebih awal karena merasa semakin lelah.' else 'b',
                    'q16': 'a' if st.session_state.q16 == 'Langsung mengomunikasikan kepada orang tersebut.' else 'b',
                    'q17': 'a' if st.session_state.q17 == 'Intuisi' else 'b',
                    'q18': 'a' if st.session_state.q18 == '"Peluang Bisnis di Masa Depan"' else 'b',
                    'q19': ['a', 'b', 'c', 'd'][['Mencari kesalahan pada orang lain atau faktor eksternal untuk menjelaskan kegagalan tersebut.',
                                                'Merenung dalam kesendirian, merasa sangat kecewa dan mempertanyakan kemampuan diri sendiri secara mendalam.',
                                                'Menganalisis setiap langkah yang salah secara objektif untuk menemukan pelajaran berharga, meskipun terasa menyakitkan.',
                                                'Segera bangkit dan mencari peluang baru, meskipun ada rasa takut akan terulangnya kegagalan.'].index(st.session_state.q19)],
                    'q20': ['a', 'b', 'c', 'd'][['Kesempatan yang terlewatkan untuk belajar atau mengembangkan diri.',
                                                'Hubungan yang rusak atau konflik yang belum terselesaikan.',
                                                'Keputusan yang menyebabkan penyesalan mendalam atau rasa bersalah.',
                                                'Momen ketidakberdayaan atau kerentanan yang membuat Anda merasa lemah.'].index(st.session_state.q20)],
                    'q21': ['a', 'b', 'c', 'd'][['Jaminan dan pujian yang meyakinkan akan nilai diri Anda.',
                                                'Ruang dan waktu untuk memproses emosi sendiri tanpa interupsi.',
                                                'Dukungan praktis dan saran konkret untuk mengatasi masalah.',
                                                'Pengertian dan penerimaan tanpa syarat, bahkan di saat terlemah Anda.'].index(st.session_state.q21)],
                    'q22': ['a', 'b', 'c', 'd'][['Mencari kebahagiaan dan kepuasan pribadi.',
                                                'Memberikan kontribusi positif bagi masyarakat dan lingkungan.',
                                                'Mencapai potensi tertinggi diri sendiri dan terus belajar.',
                                                'Menemukan makna dan kebenaran universal.'].index(st.session_state.q22)],
                    'q23': ['a', 'b', 'c', 'd'][['Setiap individu menerima apa yang pantas mereka dapatkan berdasarkan usaha dan meritokrasi.',
                                                'Sumber daya dan peluang didistribusikan secara merata untuk mengurangi ketimpangan.',
                                                'Semua orang memiliki hak dan kesempatan yang sama di mata hukum, tanpa memandang latar belakang.',
                                                'Sistem yang memastikan perlindungan bagi yang paling rentan dan memberikan kesempatan kedua bagi yang gagal.'].index(st.session_state.q23)],
                    'q24': ['a', 'b', 'c', 'd'][['Kebenaran yang menyakitkan, karena saya percaya kejujuran adalah fondasi dari pertumbuhan.',
                                                'Ilusi yang membahagiakan, jika itu melindungi diri saya atau orang lain dari penderitaan yang tidak perlu.',
                                                'Mencari cara untuk menemukan kebenaran yang dapat diterima, meskipun itu berarti menghadapi kenyataan yang sulit.',
                                                'Saya akan mempertimbangkan konteks dan dampaknya sebelum memutuskan.'].index(st.session_state.q24)],
                    'q25': ['a', 'b', 'c', 'd'][['Sebagai alat untuk meningkatkan efisiensi dan kenyamanan hidup.',
                                                'Sebagai pendorong evolusi kesadaran dan pemahaman manusia.',
                                                'Sebagai potensi ancaman terhadap kemanusiaan jika tidak dikelola dengan bijak.',
                                                'Sebagai sarana untuk menjembatani kesenjangan dan menciptakan dunia yang lebih inklusif.'].index(st.session_state.q25)]
                }
                
                # Generate answer text
                answer_text = generate_answer_text(answers)
                st.session_state.answers_text = answer_text
                st.session_state.submitted = True
                st.rerun()
    
    elif st.session_state.submitted and not st.session_state.confirmed:
        # Show answers for confirmation
        st.success("✅ Semua Pertanyaan Berhasil Dijawab!")
        st.subheader("📋 Ringkasan Jawaban Anda:")
        
        # Display answers in a text area
        st.text_area("Jawaban Anda:", st.session_state.answers_text, height=400, disabled=True)
        
        st.markdown("### Konfirmasi")
        st.markdown("**Anda menjawab semua pertanyaan dengan jawaban di atas. Apakah Anda yakin ingin melanjutkan untuk mendapatkan prediksi MBTI?**")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Ya, Lanjutkan", type="primary", use_container_width=True):
                st.session_state.confirmed = True
                st.rerun()
        with col2:
            if st.button("Kembali untuk Mengubah Jawaban", use_container_width=True):
                st.session_state.submitted = False
                st.rerun()
    
    else:
        # Process with Gemini API and show results
        if not st.session_state.mbti_result:
            st.info("🔄 Sedang memproses jawaban Anda dengan AI...")
            
            # Get MBTI prediction from Gemini
            success, result = get_mbti_from_gemini(st.session_state.answers_text)
            
            if success:
                st.session_state.mbti_result = result
                # Save to file
                save_success, save_message = save_mbti_guess(result)
                if save_success:
                    st.success("✅ Analisis Selesai!")
                else:
                    st.warning(f"⚠️ Gagal menyimpan hasil: {save_message}")
            else:
                st.error(f"❌ Error: {result}")
                st.session_state.mbti_result = "ERROR"
                # Show retry button
                if st.button("🔄 Coba Lagi", type="primary", use_container_width=True):
                    st.session_state.mbti_result = ""
                    st.rerun()
        
        if st.session_state.mbti_result and st.session_state.mbti_result != "ERROR":
            st.balloons()
            st.success("🎉 Analisis Kepribadian Selesai!")
            
            # Display results
            st.markdown("### 🧠 Prediksi Tipe MBTI Anda:")
            st.markdown(f"## **{st.session_state.mbti_result}**")
                        
            st.markdown("---")

if __name__ == "__main__":
    main()