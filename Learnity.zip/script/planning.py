import streamlit as st
import json
import os
from datetime import datetime, timedelta
import requests
import uuid
import google.generativeai as genai

# Configure Streamlit page
st.set_page_config(
    page_title="Planning Quest App",
    page_icon="🎯",
    layout="wide"
)

st.markdown(
    """
    <style>
    div.stButton > button {
        width: 100%;
        padding: 10px;
        background-color: #0d6efd;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    div.stButton > button:hover {
        background-color: #0b5ed7;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <style>
    div.stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
    }
    </style>
    """,
    unsafe_allow_html=True
)

# Initialize session state
if 'plans' not in st.session_state:
    st.session_state.plans = []
if 'chat_messages' not in st.session_state:
    st.session_state.chat_messages = []
if 'ai_mode' not in st.session_state:
    st.session_state.ai_mode = "offline"
if 'current_user_id' not in st.session_state:
    st.session_state.current_user_id = '123456789'
if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
if 'user_data' not in st.session_state:
    st.session_state.user_data = None

def load_user_data():
    """Load current user data from JSON list"""
    try:
        with open('database/user_data.json', 'r') as f:
            data = json.load(f)
        
        # Cari user berdasarkan userid
        current_id = st.session_state.get('current_user_id')
        for user in data:
            if user['userid'] == current_id:
                return user
        
        # st.error("User not found in database.")
        return None

    except FileNotFoundError:
        st.error("User data file not found!")
        return None
    except json.JSONDecodeError:
        st.error("Invalid JSON format in user data file!")
        return None

def save_user_data(updated_user):
    """Update current user data back to JSON list"""
    try:
        with open('database/user_data.json', 'r') as f:
            data = json.load(f)
        
        for i, user in enumerate(data):
            if user['userid'] == updated_user['userid']:
                data[i] = updated_user
                break
        else:
            st.warning("User not found, adding as new.")
            data.append(updated_user)

        with open('database/user_data.json', 'w') as f:
            json.dump(data, f, indent=2)
        
        return True
    except Exception as e:
        st.error(f"Error saving user data: {e}")
        return False

def load_plans():
    """Load plans from JSON file"""
    try:
        with open('database/user_plans.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except json.JSONDecodeError:
        return []

def save_plans(plans):
    """Save plans to JSON file"""
    try:
        os.makedirs('database', exist_ok=True)
        with open('database/user_plans.json', 'w') as f:
            json.dump(plans, f, indent=2)
        return True
    except Exception as e:
        st.error(f"Error saving plans: {e}")
        return False

def get_ollama_response(message):
    """Get response from Ollama (offline AI)"""
    try:
        response = requests.post(
            'http://localhost:11434/api/generate',
            json={
                'model': 'llama3.2:latest',
                'prompt': message,
                'stream': False
            },
            timeout=30
        )
        if response.status_code == 200:
            return response.json().get('response', 'Sorry, I could not generate a response.')
        else:
            return "Error: Could not connect to Ollama. Make sure it's running."
    except requests.exceptions.RequestException:
        return "Error: Could not connect to Ollama. Make sure it's running on localhost:11434."

def get_gemini_response(message, api_key):
    """Get response from Gemini (online AI)"""
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-1.5-flash')
        gemini_chat_result = model.generate_content(message)
        return gemini_chat_result.text
    except Exception as e:
        return f"Error connecting to Gemini: {e}"

def add_coins(amount):
    """Add coins to user account"""
    if st.session_state.user_data:
        st.session_state.user_data['coins'] += amount
        save_user_data(st.session_state.user_data)
        st.success(f"🪙 +{amount} coins earned! Total: {st.session_state.user_data['coins']}")

def authenticate_user(username_or_id, password):
    """Authenticate user with username/userid and password"""
    with open("database/user_data.json", "r") as user_data:
        data = json.load(user_data)
    users = data
    if users is None:
        return None
    for user in users:
        if (user.get("username") == username_or_id or 
            user.get("userid") == username_or_id) and \
           user.get("password") == password:
            return user
    return None

with st.sidebar:
    if not st.session_state.logged_in:
        st.markdown("### 🔐 Login to Learnity")
        with st.container():
            username_input = st.text_input(
                "Username or User ID",
                placeholder="Enter your username or user ID",
                help="You can use either your username or user ID to login"
            )
            password_input = st.text_input(
                "Password",
                placeholder="Enter your password"
            )
            if st.button("🚀 Login", use_container_width=True):
                if username_input and password_input:
                    user_data = authenticate_user(username_input, password_input)
                    if user_data:
                        st.session_state.logged_in = True
                        st.session_state.user_data = user_data
                        st.success("Login successful!")
                        st.rerun()
                    else:
                        st.error("Invalid credentials. Please try again.")
                else:
                    st.warning("Please fill in all fields.")

def main():
    # Load user data on first run
    if st.session_state.user_data is None:
        st.session_state.user_data = load_user_data()
    
    # Load plans on first run
    if not st.session_state.plans:
        st.session_state.plans = load_plans()

    if st.session_state.user_data is None:
        # st.error("Could not load user data. Please check your database/user_data.json file.")
        return

    # Sidebar
    if st.session_state.logged_in:
        with st.sidebar:
            st.write("Login sebagai:")
            st.code(st.session_state.user_data['username'])
            # Display user avatar based on MBTI
            mbti = st.session_state.user_data.get('mbti', 'ISFJ').lower()
            image_path = f"image/char/{mbti}_char.png"

            try:
                st.image(image_path, caption=f"Hello, {st.session_state.user_data['username']}!")
            except:
                st.write(f"🎭 Hello, {st.session_state.user_data['username']}!")
                st.caption(f"MBTI: {st.session_state.user_data['mbti_display']}")

            # User stats
            st.write("---")
            st.write(f"**Username:** {st.session_state.user_data['username']}")
            st.write(f"**Role:** {st.session_state.user_data['user_role']}")
            st.write(f"**Coins:** 🪙 {st.session_state.user_data['coins']}")
            st.write(f"**Highest Score:** {st.session_state.user_data['highest_score']}")

            # AI Mode Toggle
            st.write("---")
            st.write("**AI Assistant Mode**")
            ai_mode = st.radio(
                "Choose AI Mode:",
                ["Offline", "Online"],
                index=0 if st.session_state.ai_mode == "Offline" else 1
            )
            st.session_state.ai_mode = ai_mode

            if ai_mode == "Offline":
                st.info("🤖 Saat ini menggunakan mode Offline.")
            else:
                st.info("🌐 Saat ini menggunakan mode Online.")
                gemini_api = "AIzaSyDtiSp1xssRCPDvzP3bM_L9XcX5waUaYU8"

        # Main content
        st.title("🎯 Planning Quest App")
        st.write(f"Welcome back, **{st.session_state.user_data['username']}**! Ready to complete some quests today?")

        # Tabs
        tab1, tab2, tab3 = st.tabs(["📋 My Plans", "🤖 AI Assistant", "➕ Create Plan"])

        with tab1:
            st.header("📋 My Quest Plans")

            if not st.session_state.plans:
                st.info("No plans yet. Create your first quest plan in the 'Create Plan' tab!")
            else:
                for i, plan in enumerate(st.session_state.plans):
                    with st.expander(f"🎯 {plan['title']} - Priority: {plan['priority'].title()}", expanded=True):
                        col1, col2 = st.columns([3, 1])

                        with col1:
                            st.write(f"**Description:** {plan['description']}")
                            st.write(f"**Created:** {plan['created_date']}")
                            st.write(f"**Deadline:** {plan['deadline']}")

                            # Quest items
                            st.write("**Quest Items:**")
                            for j, quest in enumerate(plan['quests']):
                                col_quest, col_status, col_action = st.columns([3, 1, 1])

                                with col_quest:
                                    status_icon = "✅" if quest['completed'] else "⭕"
                                    st.write(f"{status_icon} {quest['title']}")
                                    if quest['deadline']:
                                        st.caption(f"Deadline: {quest['deadline']}")

                                with col_status:
                                    if quest['completed']:
                                        st.success("Done!")
                                    else:
                                        st.warning("Pending")

                                with col_action:
                                    if not quest['completed']:
                                        if st.button(f"Complete", key=f"complete_{i}_{j}"):
                                            # Mark quest as completed
                                            st.session_state.plans[i]['quests'][j]['completed'] = True
                                            st.session_state.plans[i]['quests'][j]['completed_date'] = datetime.now().strftime("%Y-%m-%d")

                                            # Award coins based on priority
                                            coin_reward = {"low": 2, "medium": 5, "high": 8}[plan['priority']]
                                            add_coins(coin_reward)

                                            # Save plans
                                            save_plans(st.session_state.plans)
                                            st.rerun()

                        with col2:
                            # Plan management buttons
                            if st.button(f"🗑️ Delete Plan", key=f"delete_{i}"):
                                st.session_state.plans.pop(i)
                                save_plans(st.session_state.plans)
                                st.rerun()

                            if st.button(f"✏️ Edit Plan", key=f"edit_{i}"):
                                st.session_state[f'editing_{i}'] = True

                            # Quick stats
                            completed_quests = sum(1 for q in plan['quests'] if q['completed'])
                            total_quests = len(plan['quests'])
                            progress = completed_quests / total_quests if total_quests > 0 else 0

                            st.metric("Progress", f"{completed_quests}/{total_quests}")
                            st.progress(progress)

        with tab2:
            st.header("🤖 AI Assistant")
            st.write("Ask me anything about planning, productivity, or life advice!")

            # Display current AI mode
            mode_color = "🤖" if st.session_state.ai_mode == "offline" else "🌐"
            st.info(f"{mode_color} Current mode: {st.session_state.ai_mode.title()}")

            # Chat interface
            for message in st.session_state.chat_messages:
                with st.chat_message(message["role"]):
                    st.write(message["content"])

            # Chat input
            if prompt := st.chat_input("Ask me anything..."):
                # Add user message
                st.session_state.chat_messages.append({"role": "user", "content": prompt})

                with st.chat_message("user"):
                    st.write(prompt)

                # Get AI response
                with st.chat_message("assistant"):
                    with st.spinner("Thinking..."):
                        if st.session_state.ai_mode == "offline":
                            response = get_ollama_response(prompt)
                        else:
                            response = get_gemini_response(prompt, gemini_api if 'gemini_api' in locals() else "AIzaSyDtiSp1xssRCPDvzP3bM_L9XcX5waUaYU8")

                        st.write(response)
                        st.session_state.chat_messages.append({"role": "assistant", "content": response})

        with tab3:
            st.header("➕ Create New Quest Plan")

            # Quest items management (outside form)
            st.write("**Quest Items:**")

            # Initialize quest items
            if 'quest_items' not in st.session_state:
                st.session_state.quest_items = [{"title": "", "deadline": ""}]

            # Display quest items
            for i, quest in enumerate(st.session_state.quest_items):
                col1, col2, col3 = st.columns([3, 2, 1])

                with col1:
                    quest_title = st.text_input(f"Quest {i+1} Title", key=f"quest_title_{i}", placeholder="e.g., Study German")
                    st.session_state.quest_items[i]["title"] = quest_title

                with col2:
                    quest_deadline = st.date_input(f"Quest {i+1} Deadline", key=f"quest_deadline_{i}", value=datetime.now() + timedelta(days=1))
                    st.session_state.quest_items[i]["deadline"] = quest_deadline.strftime("%Y-%m-%d")

                with col3:
                    if len(st.session_state.quest_items) > 1:
                        if st.button("🗑️", key=f"remove_quest_{i}"):
                            st.session_state.quest_items.pop(i)
                            st.rerun()

            # Add quest item button
            if st.button("➕ Add Quest Item"):
                st.session_state.quest_items.append({"title": "", "deadline": ""})
                st.rerun()

            st.write("---")

            # Plan creation form
            with st.form("create_plan"):
                title = st.text_input("Plan Title*", placeholder="e.g., Learn Languages in 1 Week")
                description = st.text_area("Plan Description", placeholder="Describe your quest plan...")
                priority = st.selectbox("Priority Level", ["low", "medium", "high"])
                deadline = st.date_input("Plan Deadline", value=datetime.now() + timedelta(days=7))

                submit = st.form_submit_button("🎯 Create Plan", type="primary")

                if submit:
                    if title and any(q["title"] for q in st.session_state.quest_items):
                        # Create new plan
                        new_plan = {
                            "id": str(uuid.uuid4()),
                            "title": title,
                            "description": description,
                            "priority": priority,
                            "created_date": datetime.now().strftime("%Y-%m-%d"),
                            "deadline": deadline.strftime("%Y-%m-%d"),
                            "quests": [
                                {
                                    "title": q["title"],
                                    "deadline": q["deadline"],
                                    "completed": False,
                                    "completed_date": None
                                }
                                for q in st.session_state.quest_items if q["title"]
                            ]
                        }

                        st.session_state.plans.append(new_plan)
                        save_plans(st.session_state.plans)

                        # Reset quest items
                        st.session_state.quest_items = [{"title": "", "deadline": ""}]

                        st.success("🎯 Quest plan created successfully!")
                        st.rerun()
                    else:
                        st.error("Please fill in the plan title and at least one quest item.")

if __name__ == "__main__":
    main()