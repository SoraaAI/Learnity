import webview
import os
from datetime import datetime

def main():
    html_file = 'questions.html'
    webview.create_window(
        title='Kuis Psikologi dan Filosofi',
        url=html_file,
        width=1840,
        height=920,
        min_size=(600, 600),
        resizable=True,
        shadow=True,
    )
    webview.start(debug=True)

if __name__ == '__main__':
    main()