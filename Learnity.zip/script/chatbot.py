import streamlit as st
import requests
from PIL import Image
import os
import socket
import threading
import time
import json
import subprocess
from datetime import datetime
import google.generativeai as genai

# ==== CONFIG ====
OLLAMA_URL = "http://localhost:11434"
MODEL_NAME = "llama3.2:latest"
CHAT_HISTORY_FILE = "database/chat_history.json"
GEMINI_API = ["AIzaSyCGxd6Amr7ofBhdIjE852B0mnBDyZ6jcKw", "AIzaSyBEgn_GOFRJHo2gwt2eG_lFzCyBkhwNisM", "AIzaSyCW9PIEWhKwIEneXd4vum-2VokTed51hn4", "AIzaSyCs3IiV9eZP5MZ-LGY_IBmCytvBzzq45Uo", "AIzaSyCpd_d7alhSm5-OFKbGv0Hu8QCWVex5-s4", "AIzaSyARZNLOvZV81F39V3pGsIJv2_Z9s0sBMl4", "AIzaSyB6UH8o9ojJGDKR5fRuooZ6qVBUhzZHcLM", "AIzaSyARU9APHRzRzPvWnGMmxvzFVt9FeFw8WIw", "AIzaSyDtiSp1xssRCPDvzP3bM_L9XcX5waUaYU8", "AIzaSyAolqcambI-LywE-sHrBzizyQHXBs37c3Q", "AIzaSyCslxIWJZk_9fFfEuW_jApl9aHymrmWBpQ"]

st.set_page_config(page_title="AI Pendamping Learnity", layout="wide")

# === LOAD DATABASE ===
with open("database/user_data.json", "r") as user_data:
    data = json.load(user_data)

# === CHECK INTERNET || EXPIRED ===

internet_status = ""

def internet():
    global internet_status
    try:
        x = requests.get("https://www.google.com/", timeout=3)
        if x.ok or x.status_code == 200:
            internet_status = "Online"
        else:
            internet_status = "Offline"
    except:
        internet_status = "Offline"

# ==== CHAT HISTORY FUNCTIONS ====
def load_chat_history():
    """Load chat history from JSON file."""
    try:
        if os.path.exists(CHAT_HISTORY_FILE):
            with open(CHAT_HISTORY_FILE, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:  # Check if file is not empty
                    return json.loads(content)
                else:
                    # File exists but is empty, create default structure
                    default_data = {"sessions": []}
                    save_chat_history(default_data)
                    return default_data
        else:
            # Create empty chat history file if it doesn't exist
            os.makedirs(os.path.dirname(CHAT_HISTORY_FILE), exist_ok=True)
            default_data = {"sessions": []}
            save_chat_history(default_data)
            return default_data
    except (json.JSONDecodeError, Exception) as e:
        # If JSON is corrupted or any other error, create fresh file
        print(f"Chat history file corrupted or error occurred: {e}")
        default_data = {"sessions": []}
        try:
            save_chat_history(default_data)
        except:
            pass  # If we can't save, just return default
        return default_data

def save_chat_history(chat_data):
    """Save chat history to JSON file."""
    try:
        os.makedirs(os.path.dirname(CHAT_HISTORY_FILE), exist_ok=True)
        with open(CHAT_HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(chat_data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        st.error(f"Error saving chat history: {e}")

def add_message_to_history(role, content):
    """Add a single message to chat history."""
    chat_history = load_chat_history()
    
    # If this is the first message of a new session, create a new session
    if not st.session_state.get("current_session_id"):
        session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        st.session_state.current_session_id = session_id
        
        new_session = {
            "session_id": session_id,
            "timestamp": datetime.now().isoformat(),
            "username": st.session_state.user_data.get("username", "user"),
            "messages": []
        }
        chat_history["sessions"].append(new_session)
    
    # Find current session and add message
    for session in chat_history["sessions"]:
        if session["session_id"] == st.session_state.current_session_id:
            session["messages"].append({
                "role": role,
                "content": content,
                "timestamp": datetime.now().isoformat()
            })
            # Update session timestamp to reflect latest activity
            session["timestamp"] = datetime.now().isoformat()
            break
    
    save_chat_history(chat_history)

def load_session_messages(session_id):
    """Load messages from a specific session."""
    chat_history = load_chat_history()
    for session in chat_history["sessions"]:
        if session["session_id"] == session_id:
            # Convert to the format expected by st.session_state.messages
            return [{"role": msg["role"], "content": msg["content"]} for msg in session["messages"]]
    return []

# ==== UTILS ====
def get_local_ip():
    """Returns the actual LAN IP (192.168.x.x or similar)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))  # Dummy route to external IP
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip

def find_free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        return s.getsockname()[1]

def create_flask_server():
    from flask import Flask, request, jsonify

    app = Flask(__name__)

    @app.route('/chat', methods=['POST'])
    def chat():
        data = request.json
        user_messages = data.get("messages", [])
        system_prompt = data.get("system_prompt", "You are a helpful assistant.")

        try:
            response = requests.post(
                f"{OLLAMA_URL}/api/chat",
                json={
                    "model": MODEL_NAME,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        *user_messages
                    ],
                    "stream": False
                }
            )
            reply = response.json()["message"]["content"]
        except Exception:
            reply = "⚠️ Gagal terhubung ke Ollama dari server."

        return jsonify({"reply": reply})

    return app

def start_flask_server(app, host, port):
    try:
        app.run(host=host, port=port)
    except OSError:
        # If the port is already used, find another
        new_port = find_free_port()
        st.session_state.server_port = new_port
        app.run(host=host, port=new_port)

# ==== INIT SESSION STATE ====
if "messages" not in st.session_state:
    st.session_state.messages = []

if "current_session_id" not in st.session_state:
    st.session_state.current_session_id = None

if "local_ip" not in st.session_state:
    st.session_state.local_ip = get_local_ip()

if "use_http" not in st.session_state:
    st.session_state.use_http = False

if "server_port" not in st.session_state:
    st.session_state.server_port = 5000

if "server_thread" not in st.session_state:
    st.session_state.server_thread = None

if "server_running" not in st.session_state:
    st.session_state.server_running = False

if "show_chat_history" not in st.session_state:
    st.session_state.show_chat_history = False

if "show_guide" not in st.session_state:
    st.session_state.show_guide = False

if "voice_text" not in st.session_state:
    st.session_state.voice_text = ""

if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False

if 'user_data' not in st.session_state:
    st.session_state.user_data = None

# === BUTTON STYLE ===
button_style = """
<style>
div.stButton > button {
    width: 100%;
    padding: 10px;
    background-color: #0d6efd;
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
}
</style>
"""
st.sidebar.markdown(button_style, unsafe_allow_html=True)

# === LOGIN ===

def authenticate_user(username_or_id, password):
    """Authenticate user with username/userid and password"""
    users = data
    if users is None:
        return None

    for user in users:
        if (user.get("username") == username_or_id or 
            user.get("userid") == username_or_id) and \
           user.get("password") == password:
            return user
    return None

# ==== SIDEBAR ====

with st.sidebar:
    if not st.session_state.logged_in:
        st.markdown("### 🔐 Login to Learnity")
        with st.container():
            username_input = st.text_input(
                "Username or User ID",
                placeholder="Enter your username or user ID",
                help="You can use either your username or user ID to login"
            )
            password_input = st.text_input(
                "Password",
                placeholder="Enter your password"
            )
            if st.button("🚀 Login", use_container_width=True):
                if username_input and password_input:
                    user_data = authenticate_user(username_input, password_input)
                    if user_data:
                        st.session_state.logged_in = True
                        st.session_state.user_data = user_data
                        st.success("Login successful!")
                        st.rerun()
                    else:
                        st.error("Invalid credentials. Please try again.")
                else:
                    st.warning("Please fill in all fields.")

if st.session_state.logged_in:
    st.sidebar.title("⚙️ Chatbot Settings")
    st.sidebar.text("Login sebagai:")
    # st.sidebar.code("Sora AI", language='')
    st.sidebar.code(st.session_state.user_data.get("username", "user"))

    system_prompt = st.sidebar.text_area(
        "System Prompt", 
        value="You are a helpful assistant.", 
        height=100
    )

    with st.sidebar.expander("Setting AI", expanded=True):
        ai_mode = st.radio(
                "Choose AI Mode:",
                ["Offline", "Online"],
                key="ai_mode"
            )
        if st.session_state.ai_mode == "Online":
            internet_status = "Online"
        else:
            internet_status = "Offline"
        st.code(st.session_state.ai_mode)

    if st.sidebar.button("🔄 Reset Memory"):
        st.session_state.messages = []
        st.session_state.current_session_id = None
        st.rerun()

    # ==== CHAT HISTORY SECTION ====
    if st.sidebar.button("📝 Chat History"):
        st.session_state.show_chat_history = not st.session_state.show_chat_history

    if st.session_state.show_chat_history:
        st.sidebar.markdown("### 📋 Previous Sessions")
        chat_history = load_chat_history()

        if chat_history["sessions"]:
            # Sort sessions by timestamp (newest first)
            sorted_sessions = sorted(chat_history["sessions"], 
                                   key=lambda x: x["timestamp"], 
                                   reverse=True)

            # Add session state for tracking which sessions are expanded
            if "expanded_sessions" not in st.session_state:
                st.session_state.expanded_sessions = set()

            for i, session in enumerate(sorted_sessions[:10]):  # Show last 10 sessions
                session_time = datetime.fromisoformat(session["timestamp"]).strftime("%m/%d %H:%M")
                session_preview = ""

                # Get first user message as preview
                for msg in session["messages"]:
                    if msg["role"] == "user":
                        session_preview = msg["content"][:25] + "..." if len(msg["content"]) > 25 else msg["content"]
                        break
                    
                if not session_preview:
                    session_preview = "New session"

                session_id = session["session_id"]
                msg_count = len(session["messages"])

                # Session header with expand/collapse button
                col1, col2 = st.sidebar.columns([0.8, 0.2])

                with col1:
                    session_label = f"🕐 {session_time}: {session_preview}"
                    st.write(f"**{session_label}**")
                    st.caption(f"{msg_count} messages")

                with col2:
                    # Toggle expand/collapse
                    if session_id in st.session_state.expanded_sessions:
                        if st.button("▼", key=f"collapse_{session_id}"):
                            st.session_state.expanded_sessions.discard(session_id)
                            st.rerun()
                    else:
                        if st.button("▶", key=f"expand_{session_id}"):
                            st.session_state.expanded_sessions.add(session_id)
                            st.rerun()

                # Show expanded content if session is expanded
                if session_id in st.session_state.expanded_sessions:
                    with st.sidebar.container():
                        st.caption(f"**Date:** {datetime.fromisoformat(session['timestamp']).strftime('%Y-%m-%d %H:%M:%S')}")

                        # Show first few messages as preview
                        st.caption("**Preview:**")
                        preview_msgs = session["messages"][:3]  # Show first 3 messages
                        for msg in preview_msgs:
                            role_icon = "👤" if msg["role"] == "user" else "🤖"
                            content_preview = msg["content"][:40] + "..." if len(msg["content"]) > 40 else msg["content"]
                            st.caption(f"{role_icon} {content_preview}")

                        if msg_count > 3:
                            st.caption(f"... and {msg_count - 3} more messages")

                        # Action buttons
                        col_load, col_delete = st.columns(2)

                        with col_load:
                            if st.button("📂 Load", key=f"load_session_{session_id}"):
                                # Load the previous session messages
                                loaded_messages = load_session_messages(session_id)
                                st.session_state.messages = loaded_messages
                                st.session_state.current_session_id = session_id
                                st.session_state.show_chat_history = False
                                st.session_state.expanded_sessions.clear()
                                st.success(f"✅ Loaded session with {len(loaded_messages)} messages - AI will remember this conversation!")
                                st.rerun()

                        with col_delete:
                            if st.button("🗑️ Delete", key=f"delete_session_{session_id}"):
                                # Remove session from history
                                chat_history["sessions"] = [s for s in chat_history["sessions"] if s["session_id"] != session_id]
                                save_chat_history(chat_history)
                                st.session_state.expanded_sessions.discard(session_id)
                                st.rerun()

                st.sidebar.markdown("---")  # Separator between sessions
        else:
            st.sidebar.info("No chat history found.")
            st.sidebar.caption("Start a conversation to create your first chat session!")

    # ==== MBTI CHARACTER IMAGE ====
    try:
        if st.session_state.logged_in:
            mbti = st.session_state.user_data.get("mbti", "default").lower()
        img_path = f"image/char/{mbti}_char.png"
        if os.path.exists(img_path):
            char_img = Image.open(img_path)
            st.sidebar.markdown("---")
            st.sidebar.image(char_img, caption=mbti.upper(), use_container_width=True)
        else:
            st.sidebar.warning(f"⚠️ Gambar karakter untuk MBTI '{mbti.upper()}' tidak ditemukan di {img_path}.")
    except Exception:
        pass

    # ==== SERVER CONFIGURATION ====
    st.sidebar.markdown("---")
    st.sidebar.subheader("🌐 Server Configuration")
    with st.sidebar.expander("📡 Show Local IP", expanded=False):
        st.code(st.session_state.local_ip, language='text')

    # Check for Flask availability
    try:
        import flask
        HTTP_AVAILABLE = True
    except ImportError:
        HTTP_AVAILABLE = False

    if HTTP_AVAILABLE:
        with st.sidebar.expander("📡 HTTP Server Settings", expanded=False):
            use_http = st.checkbox("Use HTTP Localhost Server", key="use_http")

            if use_http:
                server_port = st.number_input("Server Port", min_value=1000, max_value=9999, value=st.session_state.server_port)
                st.session_state.server_port = server_port
                server_url = f"http://{st.session_state.local_ip}:8502"
                st.text(f"Server URL: {server_url}")

                col_start_server, col_stop_server = st.columns(2)

                with col_start_server:
                    if st.button("🚀 Start Server") and not st.session_state.server_running:
                        try:
                            app = create_flask_server()
                            st.session_state.server_thread = threading.Thread(
                                target=start_flask_server,
                                args=(app, st.session_state.local_ip, st.session_state.server_port),
                                daemon=True
                            )
                            st.session_state.server_thread.start()
                            st.session_state.server_running = True
                            time.sleep(1)  # Let the server start
                            st.success("✅ Server started!")
                        except Exception as e:
                            st.error(f"❌ Failed to start server: {e}")

                with col_stop_server:
                    if st.button("⏹️ Stop Server") and st.session_state.server_running:
                        st.session_state.server_running = False
                        st.info("ℹ️ Server marked as stopped (restart app to fully reset Flask).")

    else:
        with st.sidebar.expander("📡 HTTP Server Settings", expanded=False):
            st.warning("⚠️ Install 'requests' and 'flask' for HTTP mode")
            st.text("pip install requests flask")
            st.session_state.use_http = False
            use_http = False

    if not use_http:
        st.sidebar.info("Using local file system (no network)")

    try:
        subprocess.Popen(["ollama", "serve"])
        st.sidebar.success("Server connected.")
    except:
        st.sidebar.error("Server error.")

    st.sidebar.markdown("---")

    # === Ekstra ===

    st.sidebar.subheader("⚙️ Ekstra")

    with st.sidebar.expander("🗣️ Voice to Text", expanded=False):
        st.write("Tekan **Start Recording** untuk memulai voice input:")

        # Voice recording component using HTML/JavaScript
        voice_component = """
        <div style="text-align: center; padding: 10px;">
            <button id="startBtn" onclick="startRecording()" style="
                background-color: #4CAF50; 
                color: white; 
                padding: 10px 20px; 
                border: none; 
                border-radius: 5px; 
                cursor: pointer; 
                margin: 5px;
                font-size: 14px;
            ">🎤 Start Recording</button>

            <button id="stopBtn" onclick="stopRecording()" style="
                background-color: #f44336; 
                color: white; 
                padding: 10px 20px; 
                border: none; 
                border-radius: 5px; 
                cursor: pointer; 
                margin: 5px;
                font-size: 14px;
                display: none;
            ">⏹️ Stop Recording</button>

            <div id="status" style="margin-top: 10px; font-size: 12px; color: #666;"></div>
            <div id="result" style="
                margin-top: 10px; 
                padding: 10px; 
                background-color: #f0f0f0; 
                border-radius: 5px; 
                max-height: 150px;
                min-height: 50px;
                font-size: 14px;
                text-align: left;
                display: none;
                overflow-y: auto;
                word-wrap: break-word;
                white-space: pre-wrap;
                border: 1px solid #ddd;
            "></div>

            <button id="copyBtn" onclick="copyToClipboard()" style="
                background-color: #2196F3; 
                color: white; 
                padding: 8px 16px; 
                border: none; 
                border-radius: 5px; 
                cursor: pointer; 
                margin-top: 10px;
                font-size: 12px;
                display: none;
            ">📋 Copy Text</button>
        </div>

        <script>
        let recognition;
        let isRecording = false;
        let finalText = '';

        function checkSpeechRecognition() {
            if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
                document.getElementById('status').innerHTML = '❌ Speech recognition not supported in this browser';
                document.getElementById('startBtn').disabled = true;
                return false;
            }
            return true;
        }

        function startRecording() {
            if (!checkSpeechRecognition()) return;

            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognition = new SpeechRecognition();

            recognition.continuous = true;
            recognition.interimResults = true;
            recognition.lang = 'id-ID'; // Indonesian language, change to 'en-US' for English

            // Reset final text when starting new recording
            finalText = '';

            recognition.onstart = function() {
                isRecording = true;
                document.getElementById('startBtn').style.display = 'none';
                document.getElementById('stopBtn').style.display = 'inline-block';
                document.getElementById('status').innerHTML = '🎤 Recording... Speak now!';
                document.getElementById('result').style.display = 'block';
                document.getElementById('copyBtn').style.display = 'none';
            };

            recognition.onresult = function(event) {
                let interimTranscript = '';
                let currentFinalTranscript = '';

                for (let i = event.resultIndex; i < event.results.length; i++) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        currentFinalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }

                // Update final text with new final results
                if (currentFinalTranscript) {
                    finalText += currentFinalTranscript;
                }

                // Display the text with proper formatting
                const resultDiv = document.getElementById('result');
                let displayText = '';

                if (finalText) {
                    displayText += finalText;
                }
                if (interimTranscript) {
                    displayText += (finalText ? ' ' : '') + '[' + interimTranscript + ']';
                }

                resultDiv.innerHTML = displayText || 'Listening...';

                // Auto-scroll to bottom when new content is added
                resultDiv.scrollTop = resultDiv.scrollHeight;
            };

            recognition.onerror = function(event) {
                document.getElementById('status').innerHTML = '❌ Error: ' + event.error;
                stopRecording();
            };

            recognition.onend = function() {
                if (isRecording) {
                    stopRecording();
                }
            };

            recognition.start();
        }

        function stopRecording() {
            isRecording = false;
            if (recognition) {
                recognition.stop();
            }

            document.getElementById('startBtn').style.display = 'inline-block';
            document.getElementById('stopBtn').style.display = 'none';
            document.getElementById('status').innerHTML = '✅ Recording stopped';
            document.getElementById('copyBtn').style.display = 'inline-block';

            // Clean up the final display
            const resultDiv = document.getElementById('result');
            if (finalText) {
                resultDiv.innerHTML = finalText;
            }
        }

        function copyToClipboard() {
            const text = finalText || document.getElementById('result').innerText;

            navigator.clipboard.writeText(text).then(function() {
                document.getElementById('status').innerHTML = '📋 Text copied to clipboard! Paste it in the chat input below.';
            }).catch(function() {
                // Fallback for older browsers
                const textArea = document.createElement('textarea');
                textArea.value = text;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                document.getElementById('status').innerHTML = '📋 Text copied! Paste it in the chat input below.';
            });
        }

        // Check support on load
        window.onload = function() {
            checkSpeechRecognition();
        };
        </script>
        """

        st.components.v1.html(voice_component, height=350)

        st.caption("💡 **Tips:**")
        st.caption("• Saat ini, fitur voice-to-text hanya bisa dijalankan saat terhubung ke jaringan internet.")
        st.caption("• Sudah bisa support deteksi bahasa Indonesia.")
        st.caption("• Jangan takut kalau teks nya nanti kepanjangan, ya! Kamu bisa scroll text box nya nanti ketika teks sudah terlalu banyak.")
        st.caption("• Saat ini, fitur voice-to-text hanya bisa bekerja dengan meng-copy hasil dari teks yang sudah dikonversi.")
        st.caption("• Bekerja lebih baik jika kamu berada di suasana yang sepi dan sunyi. Ini bertujuan agar suara kamu dapat terdengar jelas.")

    if st.sidebar.button("❓Bantuan"): # Toggle Guide
        st.session_state.show_guide = not st.session_state.show_guide

    if st.session_state.logged_in:
        if st.sidebar.button("🚪Logout", use_container_width=True):
            st.session_state.logged_in = False
            st.session_state.user_data = None
            st.rerun()

# ==== MAIN ====
st.markdown("<h1 style='text-align: center; color: #4B8BBE;'>🤖 AI Pendamping Learnity</h1>", unsafe_allow_html=True)
st.markdown("---")

# Display current session info if loaded from history
if st.session_state.current_session_id and st.session_state.messages:
    chat_history = load_chat_history()
    current_session = None
    for session in chat_history["sessions"]:
        if session["session_id"] == st.session_state.current_session_id:
            current_session = session
            break
    
    if current_session:
        session_time = datetime.fromisoformat(current_session["timestamp"]).strftime("%Y-%m-%d %H:%M")
        st.info(f"💭 **Continuing conversation from {session_time}** - AI remembers {len(st.session_state.messages)} previous messages")

if st.session_state.logged_in:
    username = st.session_state.user_data.get("username", "user")
    with st.chat_message("assistant"):
        st.markdown(f"Halo, {username}! Kenalin nih, aku Learnity. Aku hadir disini buat jadi pendamping pembelajaran kamu, jadi kalau kamu ingin bertanya tentang sesuatu, jangan sungkan ya!")

if st.session_state.show_guide:
    with st.chat_message("assistant"):
        placeholder = st.empty()
        guide_text = "Nah, oke, gimana nih sebenernya cara menggunakan fitur Chatbot di Learnity? \n\nPertama, di kanan atau sidebar, ada banyak banget pilihan atau pengaturan yang bisa kalian atur nih. Salah satunya yang menarik adalah agar dapat mengatur kalian dapat menggunakan AI ini secara Offline atau Online. Selain itu, kalian juga bisa membuat chat baru dengan menekan tombol 'Reset Memory' dan juga kalian bisa melihat pembicaraan yang pernah kalian lakukan bersama Learnity dengan menekan tombol 'Chat History' dan menekan index mana yang ingin kalian lanjutkan dengan AI Learnity. \n\nNah selanjutnya, ada bagian 'Server Configuration' nih, salah satunya 'HTTP Server Settings.' \n\nApa fungsi dan tujuan dari pengaturan ini? Fungsi ini akan sangat berguna jika kalian ingin membuat device kalian menjadi server agar device atau platform lain dapat mengakses website dengan server yang sama nih. Kelebihannya? Contoh: Learnity tidak bisa dijalankan di android atau mobile, tapi dengan menggunakan suatu laptop atau komputer dan kemudian menggunakan fitur ini, maka ketika handphone kalian mengakses link localhost yang sama bisa loh! Selama komputer dan handphone kalian terhubung ke jaringan yang sama. \n\nTerakhir, ada fitur 'Voice to Text' nih. \n\nUntuk cara menggunakan fitur ini, kalian dapat menekan tombol konfigurasi 'Voice to Text' di sidebar karena deskripsi sudah dijelaskan di tab yang sama. \n\nDengan penjelasan ini, semoga kalian dapat menggunakan fitur Chatbot di Learnity dengan lancar, yaa!"
        typed_text = ""
        for char in guide_text:
            typed_text += char
            placeholder.markdown(typed_text)
            time.sleep(0.001)  # Adjust speed if needed

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

if st.session_state.logged_in:
    if prompt := st.chat_input("Say something..."):
        with st.chat_message("user"):
            st.markdown(prompt)
        add_message_to_history("user", prompt)

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                reply = "⚠️ Tidak ada respons."

                if st.session_state.ai_mode == "Offline":
                    try:
                        response = requests.post(
                            f"{OLLAMA_URL}/api/chat",
                            json={
                                "model": MODEL_NAME,
                                "messages": [
                                    {"role": "system", "content": system_prompt},
                                    *st.session_state.messages,
                                    {"role": "user", "content": prompt}
                                ],
                                "stream": False
                            }
                        )
                        reply = response.json()["message"]["content"]
                    except Exception as e:
                        reply = f"⚠️ Gagal terhubung ke Ollama:\n{e}"

                else:
                    for key in GEMINI_API:
                        try:
                            genai.configure(api_key=key)
                            model = genai.GenerativeModel('gemini-1.5-flash')
                            gemini_chat_result = model.generate_content(prompt)
                            if gemini_chat_result:
                                reply = gemini_chat_result.text
                                break
                        except Exception as e:
                            continue

                st.markdown(reply)

        st.session_state.messages.append({"role": "user", "content": prompt})
        st.session_state.messages.append({"role": "assistant", "content": reply})

        # Save to history
        add_message_to_history("assistant", reply)
else:
    with st.chat_message("assistant"):
        st.markdown("Login dulu, yuk! Buat login, bisa kamu buka sidebar dulu yaa! Kalau sudah login, baru nanti kamu bisa akses fitur yang lain. Maaf banget yaa, setiap sesi dan juga ganti page harus login ulang dulu.. :(")