import json
from streamlit_plugins.components.theme_changer.entity import ThemeInput, ThemeInfo, ThemeBaseLight, ThemeBaseDark

THEME_CONFIG_PATH = "../database/theme_config.json"

# Mapping untuk mengonversi string ke nilai numerik yang diharapkan oleh Pydantic
THEME_BASE_MAPPING = {
    "light": ThemeBaseLight.base,
    "dark": ThemeBaseDark.base
}

def get_themes_from_json():
    """Load themes from a JSON file and convert them to ThemeInput objects."""
    try:
        with open(THEME_CONFIG_PATH, "r") as f:
            raw_themes = json.load(f)
    except FileNotFoundError:
        return {}

    themes_data = {}
    for key, theme_dict in raw_themes.items():
        theme_info_dict = theme_dict.get("themeInfo", {})
        
        # Hapus kunci "font" yang tidak valid jika ada
        if "font" in theme_info_dict:
            del theme_info_dict["font"]
            
        base_value = theme_info_dict.get("base")
        if base_value in THEME_BASE_MAPPING:
            base = THEME_BASE_MAPPING[base_value]
        else:
            base = ThemeBaseLight.base

        theme_info = ThemeInfo(
            base=base,
            primaryColor=theme_info_dict.get("primaryColor", "#6100FF"),
            backgroundColor=theme_info_dict.get("backgroundColor", "#EFF4FF"),
            secondaryBackgroundColor=theme_info_dict.get("secondaryBackgroundColor", "#E7EEF5"),
            textColor=theme_info_dict.get("textColor", "#000000"),
            widgetBackgroundColor=theme_info_dict.get("widgetBackgroundColor", "#F3F5F7"),
            widgetBorderColor=theme_info_dict.get("widgetBorderColor", "#9000FF"),
            skeletonBackgroundColor=theme_info_dict.get("skeletonBackgroundColor", "#E0E0E0"),
            
            # Berikan nilai default jika input kosong atau null
            bodyFont=theme_info_dict.get("bodyFont", "sans serif") or "sans serif",
            codeFont=theme_info_dict.get("codeFont", "monospace") or "monospace",
            fontFaces=theme_info_dict.get("fontFaces", []) or [], 
            
            radii=theme_info_dict.get("radii", {"baseWidgetRadius": 0, "checkboxRadius": 0}),
            fontSizes=theme_info_dict.get("fontSizes", {"tinyFontSize": 10, "smallFontSize": 12, "baseFontSize": 14})
        )
        
        themes_data[key] = ThemeInput(
            name=theme_dict.get("name"),
            icon=theme_dict.get("icon"),
            order=theme_dict.get("order"),
            themeInfo=theme_info
        )
    return themes_data

def save_themes_to_json(themes_data):
    """Save the ThemeInput objects back to the JSON file."""
    serializable_themes = {}
    for key, theme in themes_data.items():
        serializable_theme = {
            "name": theme.name,
            "icon": theme.icon,
            "order": theme.order,
            "themeInfo": theme.themeInfo.__dict__.copy()
        }
        
        if "font" in serializable_theme["themeInfo"]:
            del serializable_theme["themeInfo"]["font"]
        
        if theme.themeInfo.base == ThemeBaseLight.base:
            serializable_theme["themeInfo"]["base"] = "light"
        elif theme.themeInfo.base == ThemeBaseDark.base:
            serializable_theme["themeInfo"]["base"] = "dark"
        
        serializable_themes[key] = serializable_theme

    with open(THEME_CONFIG_PATH, "w") as f:
        json.dump(serializable_themes, f, indent=2)